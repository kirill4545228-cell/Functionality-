package com.example.lookat;

public class Waypoint {
    public String name = "Waypoint";
    public String world = "";
    public String dim = "";
    public int x, y, z;
    public int color = 0xFF5555;
    public boolean visible = true;

    public Waypoint() {
    }

    public Waypoint(String name, String world, String dim, int x, int y, int z, int color) {
        this.name = name;
        this.world = world;
        this.dim = dim;
        this.x = x;
        this.y = y;
        this.z = z;
        this.color = color;
    }
}
