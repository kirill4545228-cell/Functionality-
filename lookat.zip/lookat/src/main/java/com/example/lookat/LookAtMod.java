package com.example.lookat;

import net.minecraftforge.fml.common.Mod;

@Mod(LookAtMod.MODID)
public class LookAtMod {
    public static final String MODID = "lookat";

    public LookAtMod() {
    }
}
