package com.example.lookat;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

import net.minecraft.resources.ResourceLocation;

@Mod.EventBusSubscriber(modid = LookAtMod.MODID, value = Dist.CLIENT,
        bus = Mod.EventBusSubscriber.Bus.MOD)
public class HudOverlay {

    @SubscribeEvent
    public static void register(RegisterGuiOverlaysEvent event) {
        event.registerAboveAll("lookat", (gui, g, partialTick, width, height) -> {
            Minecraft mc = Minecraft.getInstance();
            if (mc.options.hideGui || mc.level == null || mc.player == null
                    || mc.screen != null || mc.hitResult == null) {
                return;
            }

            Component name = null;
            Component extra = null;
            ItemStack icon = ItemStack.EMPTY;
            String namespace = null;

            HitResult hit = mc.hitResult;
            if (hit instanceof BlockHitResult bhr && bhr.getType() == HitResult.Type.BLOCK) {
                BlockPos pos = bhr.getBlockPos();
                BlockState state = mc.level.getBlockState(pos);
                if (state.isAir()) return;
                name = state.getBlock().getName();
                icon = state.getCloneItemStack(bhr, mc.level, pos, mc.player);
                ResourceLocation key = ForgeRegistries.BLOCKS.getKey(state.getBlock());
                if (key != null) namespace = key.getNamespace();
            } else if (hit instanceof EntityHitResult ehr) {
                Entity entity = ehr.getEntity();
                name = entity.getDisplayName();
                if (entity instanceof LivingEntity le) {
                    extra = Component.literal(String.format("HP: %.1f / %.1f",
                            le.getHealth(), le.getMaxHealth()));
                }
                SpawnEggItem egg = SpawnEggItem.byId(entity.getType());
                if (egg != null) icon = new ItemStack(egg);
                ResourceLocation key = ForgeRegistries.ENTITY_TYPES.getKey(entity.getType());
                if (key != null) namespace = key.getNamespace();
            }

            if (name == null || namespace == null) return;

            String ns = namespace;
            String modName = ModList.get().getModContainerById(ns)
                    .map(c -> c.getModInfo().getDisplayName()).orElse(ns);
            MutableComponent modLine = Component.literal(modName)
                    .withStyle(s -> s.withItalic(true).withColor(0x5555FF));

            draw(mc, g, width, name, extra, modLine, icon);
        });
    }

    private static void draw(Minecraft mc, GuiGraphics g, int screenW,
                             Component name, Component extra, Component modLine, ItemStack icon) {
        Font font = mc.font;
        boolean hasIcon = !icon.isEmpty();
        int iconSpace = hasIcon ? 20 : 0;

        int textW = Math.max(font.width(name), font.width(modLine));
        if (extra != null) textW = Math.max(textW, font.width(extra));
        int lines = extra != null ? 3 : 2;

        int padding = 5;
        int boxW = padding * 2 + iconSpace + textW;
        int boxH = Math.max(padding * 2 + lines * 10 - 1, padding * 2 + 16);
        int x = (screenW - boxW) / 2;
        int y = 6;

        g.fill(x - 1, y - 1, x + boxW + 1, y + boxH + 1, 0xFF000000);
        g.fill(x, y, x + boxW, y + boxH, 0xCC1A1A1A);

        if (hasIcon) {
            g.renderItem(icon, x + padding, y + (boxH - 16) / 2);
        }

        int tx = x + padding + iconSpace;
        int ty = y + padding;
        g.drawString(font, name, tx, ty, 0xFFFFFF, true);
        ty += 10;
        if (extra != null) {
            g.drawString(font, extra, tx, ty, 0xFF5555, true);
            ty += 10;
        }
        g.drawString(font, modLine, tx, ty, 0x5555FF, true);
    }
}
