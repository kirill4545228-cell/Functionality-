package com.example.lookat;

import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

import java.util.List;
import java.util.Locale;

/** Круглая миникарта: поворот, иконки мобов/игроков, точки, компас, запись в MapStore. */
public final class Minimap {
    public static boolean enabled = true;
    /** 0 = выкл, 1 = враги + игроки, 2 = все. */
    public static int radarMode = 2;
    public static boolean rotate = false;
    public static final int[] ZOOMS = {32, 64, 96};
    public static int zoomIdx = 1;
    public static boolean valid;

    private static final int N = 112;       // размер текстуры в блоках
    private static final int RADIUS = 52;   // радиус карты на экране
    private static final ResourceLocation TEX = new ResourceLocation(LookAtMod.MODID, "minimap");

    private static DynamicTexture texture;
    private static int centerX, centerZ;
    private static final int[] H = new int[N * N];
    private static final int[] C = new int[N * N];
    private static final int[] W = new int[N * N];

    private Minimap() {
    }

    // ================= обновление =================

    public static void update(Minecraft mc) {
        ClientLevel level = mc.level;
        LocalPlayer player = mc.player;
        if (level == null || player == null) return;

        if (texture == null) {
            texture = new DynamicTexture(N, N, false);
            mc.getTextureManager().register(TEX, texture);
        }
        NativeImage img = texture.getPixels();
        if (img == null) return;

        int cx = player.getBlockX();
        int cz = player.getBlockZ();
        int minY = level.getMinBuildHeight();
        int maxY = level.getMaxBuildHeight();
        boolean ceiling = level.dimensionType().hasCeiling();
        int startY = Math.min(player.getBlockY() + 3, maxY - 1) + 1;
        BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();

        for (int tz = 0; tz < N; tz++) {
            for (int tx = 0; tx < N; tx++) {
                int i = tz * N + tx;
                int wx = cx - N / 2 + tx;
                int wz = cz - N / 2 + tz;
                C[i] = 0;
                H[i] = 0;
                W[i] = 0;
                if (!level.hasChunk(wx >> 4, wz >> 4)) continue;

                int y = ceiling ? startY : level.getHeight(Heightmap.Types.WORLD_SURFACE, wx, wz);
                MapColor color = MapColor.NONE;
                BlockState st = null;
                int guard = 0;
                while (y > minY + 1 && guard++ < 64) {
                    st = level.getBlockState(mp.set(wx, y - 1, wz));
                    color = st.getMapColor(level, mp);
                    if (color != MapColor.NONE) break;
                    y--;
                }
                if (st == null || color == MapColor.NONE) continue;

                H[i] = y;
                C[i] = 0xFF000000 | color.col;
                if (st.getFluidState().is(FluidTags.WATER)) {
                    int d = 1;
                    while (d < 14 && y - 1 - d > minY
                            && level.getFluidState(mp.set(wx, y - 1 - d, wz)).is(FluidTags.WATER)) {
                        d++;
                    }
                    W[i] = d;
                }
            }
        }

        for (int tz = 0; tz < N; tz++) {
            for (int tx = 0; tx < N; tx++) {
                int i = tz * N + tx;
                if (C[i] == 0) {
                    img.setPixelRGBA(tx, tz, 0xFF111111);
                    continue;
                }
                float f;
                if (W[i] > 0) {
                    f = 1.0f - Math.min(W[i], 12) * 0.045f;
                } else {
                    int hn = (tz > 0 && C[i - N] != 0) ? H[i - N] : H[i];
                    int diff = Math.max(-3, Math.min(3, H[i] - hn));
                    f = 0.92f + diff * 0.07f;
                }
                int rgb = C[i];
                int r = Math.min(255, (int) (((rgb >> 16) & 255) * f));
                int gr = Math.min(255, (int) (((rgb >> 8) & 255) * f));
                int b = Math.min(255, (int) ((rgb & 255) * f));
                int px = 0xFF000000 | (b << 16) | (gr << 8) | r;
                img.setPixelRGBA(tx, tz, px);
                MapStore.put(cx - N / 2 + tx, cz - N / 2 + tz, px);
            }
        }
        texture.upload();
        MapStore.flush();
        centerX = cx;
        centerZ = cz;
        valid = true;
    }

    // ================= рисование =================

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private static final class View {
        final double cx, cy, wcx, wcz, cos, sin, scale;

        View(double cx, double cy, double wcx, double wcz, double phi, double scale) {
            this.cx = cx;
            this.cy = cy;
            this.wcx = wcx;
            this.wcz = wcz;
            this.cos = Math.cos(phi);
            this.sin = Math.sin(phi);
            this.scale = scale;
        }

        double sx(double wx, double wz) {
            double rx = wx - wcx;
            double rz = wz - wcz;
            return cx + (rx * cos - rz * sin) * scale;
        }

        double sy(double wx, double wz) {
            double rx = wx - wcx;
            double rz = wz - wcz;
            return cy + (rx * sin + rz * cos) * scale;
        }
    }

    private static void drawMapFan(GuiGraphics g, int cx, int cy, double tcx, double tcz,
                                   double scale, double phi) {
        RenderSystem.enableBlend();
        RenderSystem.setShader(GameRenderer::getPositionTexShader);
        RenderSystem.setShaderTexture(0, TEX);
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        Matrix4f m = g.pose().last().pose();
        BufferBuilder bb = Tesselator.getInstance().getBuilder();
        bb.begin(VertexFormat.Mode.TRIANGLE_FAN, DefaultVertexFormat.POSITION_TEX);
        bb.vertex(m, (float) cx, (float) cy, 0f).uv((float) (tcx / N), (float) (tcz / N)).endVertex();
        double cosP = Math.cos(phi);
        double sinP = Math.sin(phi);
        int seg = 64;
        for (int i = 0; i <= seg; i++) {
            double a = -2.0 * Math.PI * i / seg;
            double dx = Math.cos(a) * RADIUS;
            double dy = Math.sin(a) * RADIUS;
            double wx = (dx * cosP + dy * sinP) / scale;
            double wz = (-dx * sinP + dy * cosP) / scale;
            bb.vertex(m, (float) (cx + dx), (float) (cy + dy), 0f)
                    .uv((float) ((tcx + wx) / N), (float) ((tcz + wz) / N)).endVertex();
        }
        BufferUploader.drawWithShader(bb.end());
    }

    public static void render(GuiGraphics g, float pt, int screenW, int screenH) {
        Minecraft mc = Minecraft.getInstance();
        if (!enabled || !valid || texture == null || mc.level == null || mc.player == null
                || mc.options.hideGui) {
            return;
        }
        int cx = screenW - RADIUS - 12;
        int cy = RADIUS + 12;
        int R = ZOOMS[zoomIdx];
        double scale = (RADIUS * 2.0) / R;
        Vec3 pp = mc.player.getPosition(pt);
        double yawRad = Math.toRadians(mc.player.getViewYRot(pt));
        double phi = rotate ? Math.PI - yawRad : 0.0;

        double ox = centerX - N / 2;
        double oz = centerZ - N / 2;
        double tcx = clamp(pp.x - ox, R / 2.0 + 1, N - R / 2.0 - 1);
        double tcz = clamp(pp.z - oz, R / 2.0 + 1, N - R / 2.0 - 1);
        View view = new View(cx, cy, ox + tcx, oz + tcz, phi, scale);

        // рамка
        MapIcons.disc(g, cx, cy, RADIUS + 5, 0xFF000000);
        MapIcons.disc(g, cx, cy, RADIUS + 4, 0xFF8C8C8C);
        MapIcons.disc(g, cx, cy, RADIUS + 2, 0xFF3C3C3C);
        MapIcons.disc(g, cx, cy, RADIUS + 1, 0xFF000000);
        MapIcons.disc(g, cx, cy, RADIUS, 0xFF101010);

        // карта
        drawMapFan(g, cx, cy, tcx, tcz, scale, phi);

        double lim = RADIUS - 5;

        // точки
        List<Waypoint> wps = WaypointManager.current();
        Waypoint nearest = null;
        double best = Double.MAX_VALUE;
        for (Waypoint w : wps) {
            if (!w.visible) continue;
            double dx = w.x + 0.5 - pp.x;
            double dy = w.y - pp.y;
            double dz = w.z + 0.5 - pp.z;
            double d2 = dx * dx + dy * dy + dz * dz;
            if (d2 < best) {
                best = d2;
                nearest = w;
            }
            double sx = view.sx(w.x + 0.5, w.z + 0.5);
            double sy = view.sy(w.x + 0.5, w.z + 0.5);
            double ddx = sx - cx;
            double ddy = sy - cy;
            double d = Math.hypot(ddx, ddy);
            if (d > lim) {
                sx = cx + ddx / d * lim;
                sy = cy + ddy / d * lim;
            }
            MapIcons.waypoint(g, w, (int) Math.round(sx), (int) Math.round(sy));
        }

        // мобы и игроки
        if (radarMode > 0) {
            AABB box = mc.player.getBoundingBox().inflate(R / 2.0 + 2, 24, R / 2.0 + 2);
            List<LivingEntity> list = mc.level.getEntitiesOfClass(LivingEntity.class, box);
            for (LivingEntity e : list) {
                if (e == mc.player || e instanceof ArmorStand || e.isInvisible()) continue;
                boolean hostile = e instanceof Enemy;
                boolean pl = e instanceof Player;
                if (radarMode == 1 && !hostile && !pl) continue;
                Vec3 ep = e.getPosition(pt);
                double sx = view.sx(ep.x, ep.z);
                double sy = view.sy(ep.x, ep.z);
                if (Math.hypot(sx - cx, sy - cy) > RADIUS - 5) continue;
                MapIcons.draw(g, e, (int) Math.round(sx), (int) Math.round(sy), 8);
            }
        }

        // игрок
        double psx = view.sx(pp.x, pp.z);
        double psy = view.sy(pp.x, pp.z);
        MapIcons.arrow(g, (float) psx, (float) psy, (float) (yawRad + phi + Math.PI));

        // компас
        MapIcons.compass(g, mc.font, cx, cy, RADIUS + 4, phi);

        // инфо-строки
        BlockPos bp = mc.player.blockPosition();
        String dir = mc.player.getDirection().getName();
        dir = dir.substring(0, 1).toUpperCase(Locale.ROOT) + dir.substring(1);
        Component biome = mc.level.getBiome(bp).unwrapKey()
                .map(k -> (Component) Component.translatable(
                        "biome." + k.location().getNamespace() + "." + k.location().getPath()))
                .orElse(Component.literal("?"));
        long dayTime = mc.level.getDayTime();
        long t = dayTime % 24000L;
        int hours = (int) ((t / 1000L + 6L) % 24L);
        int mins = (int) ((t % 1000L) * 60L / 1000L);
        long day = dayTime / 24000L + 1L;

        int ty = cy + RADIUS + 10;
        String l1 = "XYZ: " + bp.getX() + " " + bp.getY() + " " + bp.getZ();
        String l3 = dir + "  Light: " + mc.level.getMaxLocalRawBrightness(bp);
        String l4 = String.format(Locale.ROOT, "Day %d  %02d:%02d", day, hours, mins);
        g.drawString(mc.font, l1, screenW - 6 - mc.font.width(l1), ty, 0xFFFFFF, true);
        g.drawString(mc.font, biome, screenW - 6 - mc.font.width(biome), ty + 10, 0xAAAAAA, true);
        g.drawString(mc.font, l3, screenW - 6 - mc.font.width(l3), ty + 20, 0xAAAAAA, true);
        g.drawString(mc.font, l4, screenW - 6 - mc.font.width(l4), ty + 30, 0xAAAAAA, true);
        if (nearest != null) {
            String l5 = nearest.name + " " + (int) Math.sqrt(best) + "m";
            g.drawString(mc.font, l5, screenW - 6 - mc.font.width(l5), ty + 40,
                    0xFF000000 | nearest.color, true);
        }
    }
}
