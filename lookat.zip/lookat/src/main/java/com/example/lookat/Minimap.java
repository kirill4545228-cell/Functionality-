package com.example.lookat;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;
import java.util.Locale;

/** Миникарта: цвета блоков сверху, маркеры точек, радар мобов, инфо-строки. */
public final class Minimap {
    public static boolean enabled = true;
    public static boolean radar = true;
    public static final int[] ZOOMS = {24, 48, 96};
    public static int zoomIdx = 1;
    public static boolean valid;

    private static final int N = 112;      // размер текстуры в блоках
    private static final int SIZE = 100;   // размер на экране
    private static final ResourceLocation TEX = new ResourceLocation(LookAtMod.MODID, "minimap");

    private static DynamicTexture texture;
    private static int centerX, centerZ;
    private static final int[] H = new int[N * N];
    private static final int[] C = new int[N * N];
    private static final int[] W = new int[N * N];

    private Minimap() {
    }

    // ---------- обновление текстуры ----------

    public static void update(Minecraft mc) {
        ClientLevel level = mc.level;
        LocalPlayer player = mc.player;
        if (level == null || player == null) return;

        if (texture == null) {
            texture = new DynamicTexture(N, N, false);
            mc.getTextureManager().register(TEX, texture);
        }
        NativeImage img = texture.getPixels();
        if (img == null) return;

        int cx = player.getBlockX();
        int cz = player.getBlockZ();
        int minY = level.getMinBuildHeight();
        int maxY = level.getMaxBuildHeight();
        boolean ceiling = level.dimensionType().hasCeiling();
        int startY = Math.min(player.getBlockY() + 3, maxY - 1) + 1;
        BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();

        for (int tz = 0; tz < N; tz++) {
            for (int tx = 0; tx < N; tx++) {
                int i = tz * N + tx;
                int wx = cx - N / 2 + tx;
                int wz = cz - N / 2 + tz;
                C[i] = 0;
                H[i] = 0;
                W[i] = 0;
                if (!level.hasChunk(wx >> 4, wz >> 4)) continue;

                int y = ceiling ? startY : level.getHeight(Heightmap.Types.WORLD_SURFACE, wx, wz);
                MapColor color = MapColor.NONE;
                BlockState st = null;
                int guard = 0;
                while (y > minY + 1 && guard++ < 64) {
                    st = level.getBlockState(mp.set(wx, y - 1, wz));
                    color = st.getMapColor(level, mp);
                    if (color != MapColor.NONE) break;
                    y--;
                }
                if (st == null || color == MapColor.NONE) continue;

                H[i] = y;
                C[i] = 0xFF000000 | color.col;
                if (st.getFluidState().is(FluidTags.WATER)) {
                    int d = 1;
                    while (d < 14 && y - 1 - d > minY
                            && level.getFluidState(mp.set(wx, y - 1 - d, wz)).is(FluidTags.WATER)) {
                        d++;
                    }
                    W[i] = d;
                }
            }
        }

        for (int tz = 0; tz < N; tz++) {
            for (int tx = 0; tx < N; tx++) {
                int i = tz * N + tx;
                if (C[i] == 0) {
                    img.setPixelRGBA(tx, tz, 0xFF111111);
                    continue;
                }
                float f;
                if (W[i] > 0) {
                    f = 1.0f - Math.min(W[i], 12) * 0.045f;
                } else {
                    int hn = (tz > 0 && C[i - N] != 0) ? H[i - N] : H[i];
                    int diff = Math.max(-3, Math.min(3, H[i] - hn));
                    f = 0.92f + diff * 0.07f;
                }
                int rgb = C[i];
                int r = Math.min(255, (int) (((rgb >> 16) & 255) * f));
                int gr = Math.min(255, (int) (((rgb >> 8) & 255) * f));
                int b = Math.min(255, (int) ((rgb & 255) * f));
                img.setPixelRGBA(tx, tz, 0xFF000000 | (b << 16) | (gr << 8) | r);
            }
        }
        texture.upload();
        centerX = cx;
        centerZ = cz;
        valid = true;
    }

    // ---------- отрисовка ----------

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private static int toScreen(double world, double origin, double u0, int base, double scale) {
        return (int) Math.round(base + (world - origin - u0) * scale);
    }

    private static void marker(GuiGraphics g, int x, int y, int color) {
        g.fill(x - 3, y - 3, x + 3, y + 3, 0xFF000000);
        g.fill(x - 2, y - 2, x + 2, y + 2, 0xFF000000 | color);
    }

    public static void render(GuiGraphics g, float pt, int screenW, int screenH) {
        Minecraft mc = Minecraft.getInstance();
        if (!enabled || !valid || texture == null || mc.level == null || mc.player == null
                || mc.options.hideGui) {
            return;
        }
        int x0 = screenW - SIZE - 6;
        int y0 = 6;
        int R = ZOOMS[zoomIdx];
        double scale = (double) SIZE / R;
        Vec3 pp = mc.player.getPosition(pt);
        double ox = centerX - N / 2;
        double oz = centerZ - N / 2;
        double u0 = clamp(pp.x - ox - R / 2.0, 0, N - R);
        double v0 = clamp(pp.z - oz - R / 2.0, 0, N - R);

        g.fill(x0 - 2, y0 - 2, x0 + SIZE + 2, y0 + SIZE + 2, 0xFF000000);
        g.blit(TEX, x0, y0, SIZE, SIZE, (float) u0, (float) v0, R, R, N, N);

        // радар
        if (radar) {
            AABB box = mc.player.getBoundingBox().inflate(R / 2.0 + 2, 24, R / 2.0 + 2);
            List<LivingEntity> list = mc.level.getEntitiesOfClass(LivingEntity.class, box);
            for (LivingEntity e : list) {
                if (e == mc.player || e instanceof ArmorStand || e.isInvisible()) continue;
                Vec3 ep = e.getPosition(pt);
                int sx = toScreen(ep.x, ox, u0, x0, scale);
                int sy = toScreen(ep.z, oz, v0, y0, scale);
                if (sx < x0 + 1 || sx > x0 + SIZE - 1 || sy < y0 + 1 || sy > y0 + SIZE - 1) continue;
                int col = e instanceof Enemy ? 0xFF3030 : (e instanceof Player ? 0x4090FF : 0x40E040);
                g.fill(sx - 1, sy - 1, sx + 1, sy + 1, 0xFF000000 | col);
            }
        }

        // точки
        List<Waypoint> wps = WaypointManager.current();
        Waypoint nearest = null;
        double best = Double.MAX_VALUE;
        for (Waypoint w : wps) {
            if (!w.visible) continue;
            double dx = w.x + 0.5 - pp.x;
            double dy = w.y - pp.y;
            double dz = w.z + 0.5 - pp.z;
            double d2 = dx * dx + dy * dy + dz * dz;
            if (d2 < best) {
                best = d2;
                nearest = w;
            }
            int sx = toScreen(w.x + 0.5, ox, u0, x0, scale);
            int sy = toScreen(w.z + 0.5, oz, v0, y0, scale);
            sx = (int) clamp(sx, x0 + 3, x0 + SIZE - 3);
            sy = (int) clamp(sy, y0 + 3, y0 + SIZE - 3);
            marker(g, sx, sy, w.color);
        }

        // игрок
        int px = toScreen(pp.x, ox, u0, x0, scale);
        int py = toScreen(pp.z, oz, v0, y0, scale);
        double yaw = Math.toRadians(mc.player.getYRot());
        int fx = px + (int) Math.round(-Math.sin(yaw) * 5);
        int fy = py + (int) Math.round(Math.cos(yaw) * 5);
        g.fill(px - 2, py - 2, px + 2, py + 2, 0xFFFFFFFF);
        g.fill(fx - 1, fy - 1, fx + 1, fy + 1, 0xFFFFFF00);

        g.drawString(mc.font, "N", x0 + SIZE / 2 - 2, y0 + 1, 0xFFFFFF, true);

        // инфо-строки
        BlockPos bp = mc.player.blockPosition();
        String dir = mc.player.getDirection().getName();
        dir = dir.substring(0, 1).toUpperCase(Locale.ROOT) + dir.substring(1);
        Component biome = mc.level.getBiome(bp).unwrapKey()
                .map(k -> (Component) Component.translatable(
                        "biome." + k.location().getNamespace() + "." + k.location().getPath()))
                .orElse(Component.literal("?"));
        int ty = y0 + SIZE + 5;
        String l1 = "XYZ: " + bp.getX() + " " + bp.getY() + " " + bp.getZ();
        String l3 = dir + "  Light: " + mc.level.getMaxLocalRawBrightness(bp);
        g.drawString(mc.font, l1, screenW - 6 - mc.font.width(l1), ty, 0xFFFFFF, true);
        g.drawString(mc.font, biome, screenW - 6 - mc.font.width(biome), ty + 10, 0xAAAAAA, true);
        g.drawString(mc.font, l3, screenW - 6 - mc.font.width(l3), ty + 20, 0xAAAAAA, true);
        if (nearest != null) {
            String l4 = nearest.name + " " + (int) Math.sqrt(best) + "m";
            g.drawString(mc.font, l4, screenW - 6 - mc.font.width(l4), ty + 30,
                    0xFF000000 | nearest.color, true);
        }
    }
}
