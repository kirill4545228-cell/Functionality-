package com.example.lookat;

import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.logging.LogUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.fml.loading.FMLPaths;
import org.slf4j.Logger;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/** Хранилище исследованной карты: регионы 128x128 блоков, текстуры + сохранение в PNG. */
public final class MapStore {
    public static final int REG = 128;
    private static final Logger LOGGER = LogUtils.getLogger();

    public static final class Region {
        public final int rx, rz;
        public final ResourceLocation loc;
        final DynamicTexture tex;
        boolean dirty, saveDirty;

        Region(int rx, int rz, ResourceLocation loc, DynamicTexture tex) {
            this.rx = rx;
            this.rz = rz;
            this.loc = loc;
            this.tex = tex;
        }
    }

    private static final Map<Long, Region> REGIONS = new HashMap<>();
    private static final Set<Long> MISSING = new HashSet<>();
    private static String ctxWorld = "";
    private static String ctxDim = "";
    private static int counter;
    private static long lastKey = Long.MIN_VALUE;
    private static Region lastRegion;

    private MapStore() {
    }

    private static long key(int rx, int rz) {
        return ((long) rx << 32) | (rz & 0xFFFFFFFFL);
    }

    private static String san(String s) {
        return s.replaceAll("[^A-Za-z0-9._-]", "_");
    }

    private static Path dir() {
        return FMLPaths.GAMEDIR.get().resolve("lookat_maps").resolve(san(ctxWorld)).resolve(san(ctxDim));
    }

    private static Path file(int rx, int rz) {
        return dir().resolve("r_" + rx + "_" + rz + ".png");
    }

    public static void setContext(String world, String dim) {
        if (world.equals(ctxWorld) && dim.equals(ctxDim)) return;
        unload();
        ctxWorld = world;
        ctxDim = dim;
    }

    private static Region register(int rx, int rz, DynamicTexture t) {
        ResourceLocation loc = new ResourceLocation(LookAtMod.MODID, "map/r" + (counter++));
        Minecraft.getInstance().getTextureManager().register(loc, t);
        return new Region(rx, rz, loc, t);
    }

    private static Region loadFromDisk(int rx, int rz) {
        Path f = file(rx, rz);
        if (!Files.exists(f)) return null;
        try (InputStream in = Files.newInputStream(f)) {
            NativeImage img = NativeImage.read(in);
            if (img.getWidth() != REG || img.getHeight() != REG) {
                img.close();
                return null;
            }
            return register(rx, rz, new DynamicTexture(img));
        } catch (Exception e) {
            LOGGER.error("Failed to load map region", e);
            return null;
        }
    }

    /** Регион или null, если ещё не исследован. */
    public static Region get(int rx, int rz) {
        long k = key(rx, rz);
        Region r = REGIONS.get(k);
        if (r != null) return r;
        if (MISSING.contains(k)) return null;
        r = loadFromDisk(rx, rz);
        if (r == null) {
            MISSING.add(k);
            return null;
        }
        REGIONS.put(k, r);
        return r;
    }

    private static Region getOrCreate(int rx, int rz) {
        Region r = get(rx, rz);
        if (r != null) return r;
        r = register(rx, rz, new DynamicTexture(REG, REG, true));
        long k = key(rx, rz);
        MISSING.remove(k);
        REGIONS.put(k, r);
        return r;
    }

    /** Записать пиксель (ABGR) в мировые координаты. */
    public static void put(int wx, int wz, int abgr) {
        int rx = Math.floorDiv(wx, REG);
        int rz = Math.floorDiv(wz, REG);
        long k = key(rx, rz);
        Region r;
        if (k == lastKey && lastRegion != null) {
            r = lastRegion;
        } else {
            r = getOrCreate(rx, rz);
            lastRegion = r;
            lastKey = k;
        }
        NativeImage img = r.tex.getPixels();
        if (img == null) return;
        img.setPixelRGBA(Math.floorMod(wx, REG), Math.floorMod(wz, REG), abgr);
        r.dirty = true;
        r.saveDirty = true;
    }

    public static void flush() {
        for (Region r : REGIONS.values()) {
            if (r.dirty) {
                r.tex.upload();
                r.dirty = false;
            }
        }
    }

    public static void saveAll() {
        for (Region r : REGIONS.values()) {
            if (!r.saveDirty) continue;
            r.saveDirty = false;
            NativeImage img = r.tex.getPixels();
            if (img == null) continue;
            try {
                Files.createDirectories(dir());
                img.writeToFile(file(r.rx, r.rz).toFile());
            } catch (Exception e) {
                LOGGER.error("Failed to save map region", e);
            }
        }
    }

    public static void unload() {
        if (REGIONS.isEmpty() && MISSING.isEmpty()) return;
        saveAll();
        Minecraft mc = Minecraft.getInstance();
        for (Region r : REGIONS.values()) {
            mc.getTextureManager().release(r.loc);
        }
        REGIONS.clear();
        MISSING.clear();
        lastRegion = null;
        lastKey = Long.MIN_VALUE;
    }
}
