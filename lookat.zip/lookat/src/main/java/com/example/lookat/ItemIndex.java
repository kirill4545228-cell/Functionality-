package com.example.lookat;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Список всех предметов + поиск (слова по названию, @мод по namespace). */
public final class ItemIndex {
    private static List<ItemStack> all;

    private ItemIndex() {
    }

    public static List<ItemStack> all() {
        if (all == null) {
            List<ItemStack> list = new ArrayList<>();
            for (Item item : ForgeRegistries.ITEMS) {
                if (item == Items.AIR) continue;
                list.add(new ItemStack(item));
            }
            list.sort((a, b) -> {
                ResourceLocation ka = ForgeRegistries.ITEMS.getKey(a.getItem());
                ResourceLocation kb = ForgeRegistries.ITEMS.getKey(b.getItem());
                boolean ma = "minecraft".equals(ka.getNamespace());
                boolean mb = "minecraft".equals(kb.getNamespace());
                if (ma != mb) return ma ? -1 : 1;
                return ka.toString().compareTo(kb.toString());
            });
            all = list;
        }
        return all;
    }

    public static List<ItemStack> search(String query) {
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        if (q.isEmpty()) return all();
        String[] tokens = q.split("\\s+");
        List<ItemStack> out = new ArrayList<>();
        for (ItemStack s : all()) {
            ResourceLocation id = ForgeRegistries.ITEMS.getKey(s.getItem());
            String name = s.getHoverName().getString().toLowerCase(Locale.ROOT);
            boolean ok = true;
            for (String t : tokens) {
                if (t.startsWith("@")) {
                    if (!id.getNamespace().contains(t.substring(1))) {
                        ok = false;
                        break;
                    }
                } else if (!name.contains(t) && !id.getPath().contains(t)) {
                    ok = false;
                    break;
                }
            }
            if (ok) out.add(s);
        }
        return out;
    }
}
