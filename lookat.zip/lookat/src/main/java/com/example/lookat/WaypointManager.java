package com.example.lookat;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mojang.logging.LogUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.core.BlockPos;
import net.minecraftforge.fml.loading.FMLPaths;
import org.slf4j.Logger;

import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** Хранение точек в config/lookat_waypoints.json (по миру/серверу и измерению). */
public final class WaypointManager {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final List<Waypoint> ALL = new ArrayList<>();
    private static final int[] PALETTE = {
            0xFF5555, 0x55FF55, 0x5555FF, 0xFFFF55, 0xFF55FF, 0x55FFFF, 0xFFAA00, 0xFFFFFF};
    private static boolean loaded;

    private WaypointManager() {
    }

    private static Path file() {
        return FMLPaths.CONFIGDIR.get().resolve("lookat_waypoints.json");
    }

    private static synchronized void ensureLoaded() {
        if (loaded) return;
        loaded = true;
        Path f = file();
        if (!Files.exists(f)) return;
        try (Reader r = Files.newBufferedReader(f)) {
            Waypoint[] arr = GSON.fromJson(r, Waypoint[].class);
            if (arr != null) {
                for (Waypoint w : arr) {
                    if (w != null) ALL.add(w);
                }
            }
        } catch (Exception e) {
            LOGGER.error("Failed to load waypoints", e);
        }
    }

    public static synchronized void save() {
        try {
            Files.writeString(file(), GSON.toJson(ALL));
        } catch (IOException e) {
            LOGGER.error("Failed to save waypoints", e);
        }
    }

    public static String worldId() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.getSingleplayerServer() != null) {
            return "sp:" + mc.getSingleplayerServer().getWorldData().getLevelName();
        }
        ServerData sd = mc.getCurrentServer();
        if (sd != null) return "mp:" + sd.ip;
        return "unknown";
    }

    public static String dimId() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return "";
        return mc.level.dimension().location().toString();
    }

    /** Точки текущего мира и измерения. */
    public static synchronized List<Waypoint> current() {
        ensureLoaded();
        String world = worldId();
        String dim = dimId();
        List<Waypoint> out = new ArrayList<>();
        for (Waypoint w : ALL) {
            if (world.equals(w.world) && dim.equals(w.dim)) out.add(w);
        }
        return out;
    }

    public static synchronized Waypoint addHere(String name) {
        ensureLoaded();
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return null;
        BlockPos p = mc.player.blockPosition();
        String n = (name == null || name.isBlank()) ? "Waypoint " + (current().size() + 1) : name;
        Waypoint w = new Waypoint(n, worldId(), dimId(), p.getX(), p.getY(), p.getZ(),
                PALETTE[ALL.size() % PALETTE.length]);
        ALL.add(w);
        save();
        return w;
    }

    /** Точка смерти: заменяет предыдущую "Death point". */
    public static synchronized void setDeathPoint() {
        ensureLoaded();
        String world = worldId();
        String dim = dimId();
        ALL.removeIf(w -> "Death point".equals(w.name) && world.equals(w.world) && dim.equals(w.dim));
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        BlockPos p = mc.player.blockPosition();
        ALL.add(new Waypoint("Death point", world, dim, p.getX(), p.getY(), p.getZ(), 0xFF0000));
        save();
    }

    public static synchronized void remove(Waypoint w) {
        ALL.remove(w);
        save();
    }
}
