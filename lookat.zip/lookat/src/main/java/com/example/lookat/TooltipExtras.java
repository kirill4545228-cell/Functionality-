package com.example.lookat;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.List;

/** В тултипе предметов: прочность числом и название мода. */
@Mod.EventBusSubscriber(modid = LookAtMod.MODID, value = Dist.CLIENT)
public final class TooltipExtras {
    private TooltipExtras() {
    }

    @SubscribeEvent
    public static void onTooltip(ItemTooltipEvent e) {
        ItemStack s = e.getItemStack();
        if (s.isEmpty()) return;
        List<Component> tip = e.getToolTip();

        if (s.isDamageableItem() && !e.getFlags().isAdvanced()) {
            int max = s.getMaxDamage();
            int left = max - s.getDamageValue();
            tip.add(Component.literal("Durability: " + left + " / " + max).withStyle(ChatFormatting.GRAY));
        }

        ResourceLocation id = ForgeRegistries.ITEMS.getKey(s.getItem());
        if (id != null) {
            String ns = id.getNamespace();
            String name = ModList.get().getModContainerById(ns)
                    .map(c -> c.getModInfo().getDisplayName()).orElse(ns);
            tip.add(Component.literal(name).withStyle(ChatFormatting.BLUE, ChatFormatting.ITALIC));
        }
    }
}
