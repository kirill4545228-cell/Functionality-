package com.example.lookat;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.WorldgenRandom;
import net.minecraft.world.phys.Vec3;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

/** Большая карта: перемещение, зум, поворот, метки по клику, сетка чанков, слайм-чанки. */
public class FullMapScreen extends Screen {
    private static double scale = 2.0;
    private static double rot = 0.0;
    private static boolean grid = false;
    private static boolean slime = false;

    private final Screen parent;
    private double cx, cz;
    private boolean centered;
    private boolean pressed, moved;
    private double pressX, pressY;
    private boolean pending;
    private int pendX, pendZ;
    private EditBox nameBox;
    private Button addBtn, cancelBtn, mobsBtn, gridBtn, slimeBtn;
    private Long seed;
    private final Map<Long, Boolean> slimeCache = new HashMap<>();
    private Waypoint hoverWp;

    public FullMapScreen(Screen parent) {
        super(Component.literal("Map"));
        this.parent = parent;
    }

    private static String mobsLabel() {
        return "Mobs: " + (Minimap.radarMode == 0 ? "Off" : (Minimap.radarMode == 1 ? "Hostile" : "All"));
    }

    private static String gridLabel() {
        return "Grid: " + (grid ? "On" : "Off");
    }

    private static String slimeLabel() {
        return "Slime: " + (slime ? "On" : "Off");
    }

    // ================= преобразования =================

    private double[] toScreen(double wx, double wz) {
        double rx = wx - cx;
        double rz = wz - cz;
        double c = Math.cos(rot);
        double s = Math.sin(rot);
        return new double[]{width / 2.0 + (rx * c - rz * s) * scale, height / 2.0 + (rx * s + rz * c) * scale};
    }

    private double[] toWorld(double sx, double sy) {
        double dx = sx - width / 2.0;
        double dy = sy - height / 2.0;
        double c = Math.cos(rot);
        double s = Math.sin(rot);
        return new double[]{cx + (dx * c + dy * s) / scale, cz + (-dx * s + dy * c) / scale};
    }

    private void centerOnPlayer() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            cx = mc.player.getX();
            cz = mc.player.getZ();
        }
    }

    // ================= инициализация =================

    @Override
    protected void init() {
        Minecraft mc = Minecraft.getInstance();
        if (!centered) {
            centerOnPlayer();
            centered = true;
        }
        if (mc.getSingleplayerServer() != null && mc.level != null
                && mc.level.dimension() == Level.OVERWORLD) {
            seed = mc.getSingleplayerServer().overworld().getSeed();
        } else {
            seed = null;
        }

        int bx = 6;
        int bw = 76;
        int y = 6;
        addRenderableWidget(Button.builder(Component.literal("Center"), b -> centerOnPlayer())
                .bounds(bx, y, bw, 20).build());
        y += 22;
        addRenderableWidget(Button.builder(Component.literal("North up"), b -> rot = 0)
                .bounds(bx, y, bw, 20).build());
        y += 22;
        mobsBtn = addRenderableWidget(Button.builder(Component.literal(mobsLabel()), b -> {
            Minimap.radarMode = (Minimap.radarMode + 1) % 3;
            b.setMessage(Component.literal(mobsLabel()));
        }).bounds(bx, y, bw, 20).build());
        y += 22;
        gridBtn = addRenderableWidget(Button.builder(Component.literal(gridLabel()), b -> {
            grid = !grid;
            b.setMessage(Component.literal(gridLabel()));
        }).bounds(bx, y, bw, 20).build());
        y += 22;
        slimeBtn = addRenderableWidget(Button.builder(Component.literal(slimeLabel()), b -> {
            slime = !slime;
            b.setMessage(Component.literal(slimeLabel()));
        }).bounds(bx, y, bw, 20).build());
        y += 22;
        addRenderableWidget(Button.builder(Component.literal("Waypoints"),
                b -> Minecraft.getInstance().setScreen(new WaypointScreen(this)))
                .bounds(bx, y, bw, 20).build());
        y += 22;
        addRenderableWidget(Button.builder(Component.literal("Close"), b -> onClose())
                .bounds(bx, y, bw, 20).build());

        nameBox = new EditBox(font, width / 2 - 90, height / 2 - 10, 180, 20, Component.literal("Name"));
        nameBox.setMaxLength(32);
        nameBox.setHint(Component.literal("Waypoint name"));
        addRenderableWidget(nameBox);
        addBtn = addRenderableWidget(Button.builder(Component.literal("Add"), b -> confirm())
                .bounds(width / 2 - 90, height / 2 + 14, 88, 20).build());
        cancelBtn = addRenderableWidget(Button.builder(Component.literal("Cancel"), b -> cancel())
                .bounds(width / 2 + 2, height / 2 + 14, 88, 20).build());
        setDialogVisible(pending);
    }

    private void setDialogVisible(boolean v) {
        nameBox.visible = v;
        nameBox.active = v;
        addBtn.visible = v;
        addBtn.active = v;
        cancelBtn.visible = v;
        cancelBtn.active = v;
    }

    private void openDialog(int x, int z) {
        pending = true;
        pendX = x;
        pendZ = z;
        nameBox.setValue("");
        setDialogVisible(true);
        setFocused(nameBox);
        nameBox.setFocused(true);
    }

    private void cancel() {
        pending = false;
        setDialogVisible(false);
    }

    private void confirm() {
        Minecraft mc = Minecraft.getInstance();
        String n = nameBox.getValue().trim();
        int y = mc.player != null ? mc.player.getBlockY() : 64;
        if (mc.level != null && mc.level.hasChunk(pendX >> 4, pendZ >> 4)) {
            y = mc.level.getHeight(Heightmap.Types.WORLD_SURFACE, pendX, pendZ);
        }
        WaypointManager.addAt(n.isEmpty() ? null : n, pendX, y, pendZ);
        cancel();
    }

    private void deleteNear(double mx, double my) {
        Waypoint best = null;
        double bd = 10 * 10;
        for (Waypoint w : WaypointManager.current()) {
            if (!w.visible) continue;
            double[] s = toScreen(w.x + 0.5, w.z + 0.5);
            double d = (s[0] - mx) * (s[0] - mx) + (s[1] - my) * (s[1] - my);
            if (d < bd) {
                bd = d;
                best = w;
            }
        }
        if (best != null) {
            WaypointManager.remove(best);
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null) {
                mc.player.displayClientMessage(Component.literal("Waypoint removed: " + best.name), true);
            }
        }
    }

    // ================= рисование =================

    private boolean isSlime(int a, int b) {
        long k = ((long) a << 32) | (b & 0xFFFFFFFFL);
        Boolean v = slimeCache.get(k);
        if (v == null) {
            v = WorldgenRandom.seedSlimeChunk(a, b, seed, 987234911L).nextInt(10) == 0;
            slimeCache.put(k, v);
        }
        return v;
    }

    private void drawRegions(GuiGraphics g) {
        double minX = Double.MAX_VALUE, maxX = -Double.MAX_VALUE;
        double minZ = Double.MAX_VALUE, maxZ = -Double.MAX_VALUE;
        int[][] corners = {{0, 0}, {width, 0}, {0, height}, {width, height}};
        for (int[] k : corners) {
            double[] w = toWorld(k[0], k[1]);
            minX = Math.min(minX, w[0]);
            maxX = Math.max(maxX, w[0]);
            minZ = Math.min(minZ, w[1]);
            maxZ = Math.max(maxZ, w[1]);
        }
        int rx0 = Math.floorDiv((int) Math.floor(minX), MapStore.REG);
        int rx1 = Math.floorDiv((int) Math.floor(maxX), MapStore.REG);
        int rz0 = Math.floorDiv((int) Math.floor(minZ), MapStore.REG);
        int rz1 = Math.floorDiv((int) Math.floor(maxZ), MapStore.REG);

        RenderSystem.enableBlend();
        PoseStack ps = g.pose();
        ps.pushPose();
        ps.translate(width / 2.0, height / 2.0, 0);
        ps.mulPose(Axis.ZP.rotation((float) rot));
        ps.scale((float) scale, (float) scale, 1f);
        ps.translate(-cx, -cz, 0);

        for (int rx = rx0; rx <= rx1; rx++) {
            for (int rz = rz0; rz <= rz1; rz++) {
                MapStore.Region r = MapStore.get(rx, rz);
                if (r == null) continue;
                g.blit(r.loc, rx * MapStore.REG, rz * MapStore.REG, MapStore.REG, MapStore.REG,
                        0f, 0f, MapStore.REG, MapStore.REG, MapStore.REG, MapStore.REG);
            }
        }

        int ix0 = (int) Math.floor(minX);
        int ix1 = (int) Math.ceil(maxX);
        int iz0 = (int) Math.floor(minZ);
        int iz1 = (int) Math.ceil(maxZ);

        if (slime && seed != null && scale >= 0.8) {
            int a0 = Math.floorDiv(ix0, 16);
            int a1 = Math.floorDiv(ix1, 16);
            int b0 = Math.floorDiv(iz0, 16);
            int b1 = Math.floorDiv(iz1, 16);
            if ((long) (a1 - a0 + 1) * (b1 - b0 + 1) <= 4000) {
                for (int a = a0; a <= a1; a++) {
                    for (int b = b0; b <= b1; b++) {
                        if (isSlime(a, b)) g.fill(a * 16, b * 16, a * 16 + 16, b * 16 + 16, 0x6055FF55);
                    }
                }
            }
        }

        if (grid && scale >= 1.5) {
            int gx0 = Math.floorDiv(ix0, 16) * 16;
            int gz0 = Math.floorDiv(iz0, 16) * 16;
            for (int x = gx0; x <= ix1; x += 16) {
                boolean reg = Math.floorMod(x, MapStore.REG) == 0;
                g.fill(x, iz0, x + 1, iz1, reg ? 0x90FFFF55 : 0x40FFFFFF);
            }
            for (int z = gz0; z <= iz1; z += 16) {
                boolean reg = Math.floorMod(z, MapStore.REG) == 0;
                g.fill(ix0, z, ix1, z + 1, reg ? 0x90FFFF55 : 0x40FFFFFF);
            }
        }
        ps.popPose();
    }

    private void drawMarkers(GuiGraphics g, int mx, int my) {
        Minecraft mc = Minecraft.getInstance();
        float pt = mc.getFrameTime();
        hoverWp = null;

        if (Minimap.radarMode > 0) {
            for (Entity e : mc.level.entitiesForRendering()) {
                if (!(e instanceof LivingEntity)) continue;
                if (e == mc.player || e instanceof ArmorStand || e.isInvisible()) continue;
                LivingEntity le = (LivingEntity) e;
                boolean hostile = e instanceof Enemy;
                boolean pl = e instanceof Player;
                if (Minimap.radarMode == 1 && !hostile && !pl) continue;
                Vec3 p = e.getPosition(pt);
                double[] s = toScreen(p.x, p.z);
                if (s[0] < -10 || s[0] > width + 10 || s[1] < -10 || s[1] > height + 10) continue;
                int sx = (int) Math.round(s[0]);
                int sy = (int) Math.round(s[1]);
                MapIcons.draw(g, le, sx, sy, 10);
                if (pl) g.drawCenteredString(font, e.getName().getString(), sx, sy + 8, 0xFFFFFF);
            }
        }

        double bd = 10 * 10;
        for (Waypoint w : WaypointManager.current()) {
            if (!w.visible) continue;
            double[] s = toScreen(w.x + 0.5, w.z + 0.5);
            if (s[0] < -10 || s[0] > width + 10 || s[1] < -10 || s[1] > height + 10) continue;
            int sx = (int) Math.round(s[0]);
            int sy = (int) Math.round(s[1]);
            MapIcons.waypoint(g, w, sx, sy);
            g.drawCenteredString(font, w.name, sx, sy + 8, 0xFF000000 | w.color);
            double d = (s[0] - mx) * (s[0] - mx) + (s[1] - my) * (s[1] - my);
            if (d < bd) {
                bd = d;
                hoverWp = w;
            }
        }

        if (mc.player != null) {
            Vec3 p = mc.player.getPosition(pt);
            double[] s = toScreen(p.x, p.z);
            double yaw = Math.toRadians(mc.player.getViewYRot(pt));
            MapIcons.arrow(g, (float) s[0], (float) s[1], (float) (yaw + rot + Math.PI));
        }
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        Minecraft mc = Minecraft.getInstance();
        g.fill(0, 0, width, height, 0xFF0B0B10);
        if (mc.level == null || mc.player == null) {
            super.render(g, mx, my, pt);
            return;
        }
        drawRegions(g);
        drawMarkers(g, mx, my);
        MapIcons.compass(g, font, width - 26, 28, 14, rot);

        double[] w = toWorld(mx, my);
        int bxw = (int) Math.floor(w[0]);
        int bzw = (int) Math.floor(w[1]);
        double dist = Math.hypot(w[0] - mc.player.getX(), w[1] - mc.player.getZ());
        String info = String.format(Locale.ROOT, "X: %d  Z: %d   (%.0f m)", bxw, bzw, dist);
        g.drawCenteredString(font, info, width / 2, height - 14, 0xFFFFFF);
        g.drawCenteredString(font, "LMB: waypoint   RMB drag: rotate   RMB click: delete   Wheel: zoom",
                width / 2, height - 26, 0xAAAAAA);
        if (slime && seed == null) {
            g.drawCenteredString(font, "Slime chunks: singleplayer overworld only", width / 2, 6, 0xFFAA55);
        }

        if (pending) {
            int px = width / 2 - 100;
            int py = height / 2 - 44;
            MapIcons.panel(g, px, py, 200, 90);
            g.drawString(font, "New waypoint at " + pendX + ", " + pendZ, px + 10, py + 12, 0x404040, false);
        }

        super.render(g, mx, my, pt);

        if (!pending && hoverWp != null) {
            List<Component> lines = new ArrayList<>();
            lines.add(Component.literal(hoverWp.name));
            lines.add(Component.literal(hoverWp.x + ", " + hoverWp.y + ", " + hoverWp.z));
            double d = Math.sqrt(Math.pow(hoverWp.x + 0.5 - mc.player.getX(), 2)
                    + Math.pow(hoverWp.z + 0.5 - mc.player.getZ(), 2));
            lines.add(Component.literal(String.format(Locale.ROOT, "%.0f m", d)));
            g.renderTooltip(font, lines, Optional.empty(), mx, my);
        }
    }

    // ================= ввод =================

    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        if (super.mouseClicked(mx, my, btn)) return true;
        if (pending) return true;
        pressed = true;
        moved = false;
        pressX = mx;
        pressY = my;
        return true;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int btn, double dx, double dy) {
        if (pending || !pressed) return super.mouseDragged(mx, my, btn, dx, dy);
        if (Math.abs(mx - pressX) + Math.abs(my - pressY) > 4) moved = true;
        if (!moved) return true;
        if (btn == 0) {
            double c = Math.cos(rot);
            double s = Math.sin(rot);
            cx -= (dx * c + dy * s) / scale;
            cz -= (-dx * s + dy * c) / scale;
        } else if (btn == 1) {
            double px = mx - dx - width / 2.0;
            double py = my - dy - height / 2.0;
            double qx = mx - width / 2.0;
            double qy = my - height / 2.0;
            rot += Math.atan2(qy, qx) - Math.atan2(py, px);
        }
        return true;
    }

    @Override
    public boolean mouseReleased(double mx, double my, int btn) {
        if (pressed && !moved && !pending) {
            pressed = false;
            if (btn == 0) {
                double[] w = toWorld(mx, my);
                openDialog((int) Math.floor(w[0]), (int) Math.floor(w[1]));
            } else if (btn == 1) {
                deleteNear(mx, my);
            }
            return true;
        }
        pressed = false;
        return super.mouseReleased(mx, my, btn);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        if (pending) return super.mouseScrolled(mx, my, delta);
        double[] before = toWorld(mx, my);
        scale = Math.max(0.2, Math.min(10.0, scale * (delta > 0 ? 1.25 : 0.8)));
        double[] after = toWorld(mx, my);
        cx += before[0] - after[0];
        cz += before[1] - after[1];
        return true;
    }

    private void pan(double dx, double dy) {
        double c = Math.cos(rot);
        double s = Math.sin(rot);
        cx -= (dx * c + dy * s) / scale;
        cz -= (-dx * s + dy * c) / scale;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int mods) {
        if (pending) {
            if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
                confirm();
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                cancel();
                return true;
            }
            return super.keyPressed(keyCode, scanCode, mods);
        }
        if (Keys.FULL_MAP.matches(keyCode, scanCode)) {
            onClose();
            return true;
        }
        switch (keyCode) {
            case GLFW.GLFW_KEY_LEFT -> {
                pan(20, 0);
                return true;
            }
            case GLFW.GLFW_KEY_RIGHT -> {
                pan(-20, 0);
                return true;
            }
            case GLFW.GLFW_KEY_UP -> {
                pan(0, 20);
                return true;
            }
            case GLFW.GLFW_KEY_DOWN -> {
                pan(0, -20);
                return true;
            }
            case GLFW.GLFW_KEY_Q -> {
                rot -= 0.1;
                return true;
            }
            case GLFW.GLFW_KEY_E -> {
                rot += 0.1;
                return true;
            }
            case GLFW.GLFW_KEY_G -> {
                grid = !grid;
                gridBtn.setMessage(Component.literal(gridLabel()));
                return true;
            }
            case GLFW.GLFW_KEY_C -> {
                if (Screen.hasControlDown()) {
                    double[] w = toWorld(RecipeScreen.mouseX(), RecipeScreen.mouseY());
                    Minecraft.getInstance().keyboardHandler.setClipboard(
                            (int) Math.floor(w[0]) + " " + (int) Math.floor(w[1]));
                } else {
                    centerOnPlayer();
                }
                return true;
            }
            default -> {
            }
        }
        return super.keyPressed(keyCode, scanCode, mods);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void onClose() {
        Minecraft.getInstance().setScreen(parent);
    }
}
