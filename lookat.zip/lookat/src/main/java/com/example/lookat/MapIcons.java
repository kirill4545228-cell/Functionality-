package com.example.lookat;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.HashMap;
import java.util.Map;

/** Иконки карты: головы мобов/игроков, точки, стрелка игрока, компас, рамки. */
public final class MapIcons {
    private record Face(int u, int v, int w, int h, int tw, int th) {
    }

    private static final Map<String, Face> FACES = new HashMap<>();

    private static void f(String n, int u, int v, int w, int h, int tw, int th) {
        FACES.put(n, new Face(u, v, w, h, tw, th));
    }

    static {
        for (String n : new String[]{"zombie", "husk", "drowned"}) f(n, 8, 8, 8, 8, 64, 64);
        f("zombie_villager", 8, 8, 8, 10, 64, 64);
        for (String n : new String[]{"skeleton", "stray", "wither_skeleton", "creeper", "enderman", "blaze"}) {
            f(n, 8, 8, 8, 8, 64, 32);
        }
        f("spider", 40, 12, 8, 8, 64, 32);
        f("cave_spider", 40, 12, 8, 8, 64, 32);
        f("pig", 8, 8, 8, 8, 64, 32);
        f("cow", 6, 6, 8, 8, 64, 32);
        f("mooshroom", 6, 6, 8, 8, 64, 32);
        f("sheep", 8, 8, 6, 6, 64, 32);
        f("chicken", 3, 3, 4, 6, 64, 32);
        f("wolf", 4, 4, 6, 6, 64, 32);
        for (String n : new String[]{"villager", "wandering_trader", "pillager", "vindicator", "evoker",
                "illusioner"}) {
            f(n, 8, 8, 8, 10, 64, 64);
        }
        f("witch", 8, 8, 8, 10, 64, 128);
        f("iron_golem", 8, 8, 8, 10, 128, 128);
        f("snow_golem", 8, 8, 8, 8, 64, 64);
        f("ghast", 16, 16, 16, 16, 64, 32);
        for (String n : new String[]{"piglin", "piglin_brute", "zombified_piglin"}) f(n, 8, 8, 10, 8, 64, 64);
        f("slime", 8, 8, 8, 8, 64, 32);
        f("magma_cube", 8, 8, 8, 8, 64, 32);
        f("rabbit", 37, 5, 5, 4, 64, 32);
        f("fox", 7, 11, 8, 6, 48, 32);
    }

    private MapIcons() {
    }

    // ---------- примитивы ----------

    public static void disc(GuiGraphics g, int cx, int cy, int r, int color) {
        for (int dy = -r; dy <= r; dy++) {
            int hw = (int) Math.round(Math.sqrt((double) r * r - (double) dy * dy));
            g.fill(cx - hw, cy + dy, cx + hw, cy + dy + 1, color);
        }
    }

    public static void panel(GuiGraphics g, int x, int y, int w, int h) {
        g.fill(x, y, x + w, y + h, 0xFF000000);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, 0xFFC6C6C6);
        g.fill(x + 1, y + 1, x + w - 2, y + 3, 0xFFFFFFFF);
        g.fill(x + 1, y + 1, x + 3, y + h - 2, 0xFFFFFFFF);
        g.fill(x + 2, y + h - 3, x + w - 1, y + h - 1, 0xFF555555);
        g.fill(x + w - 3, y + 2, x + w - 1, y + h - 1, 0xFF555555);
    }

    /** Стрелка игрока; theta — поворот в радианах (0 = вверх). */
    public static void arrow(GuiGraphics g, float x, float y, float theta) {
        PoseStack ps = g.pose();
        ps.pushPose();
        ps.translate(x, y, 0);
        ps.mulPose(Axis.ZP.rotation(theta));
        for (int yy = -7; yy <= 4; yy++) {
            int hw = Math.max(0, (yy + 7) / 2);
            g.fill(-hw - 1, yy, hw + 2, yy + 1, 0xFF000000);
        }
        for (int yy = -6; yy <= 3; yy++) {
            int hw = Math.max(0, (yy + 6) / 2);
            g.fill(-hw, yy, hw + 1, yy + 1, 0xFFFFFFFF);
        }
        ps.popPose();
    }

    /** Компас: N/E/S/W в синих рамках вокруг точки; phi — поворот карты. */
    public static void compass(GuiGraphics g, Font font, int cx, int cy, int r, double phi) {
        String[] letters = {"N", "E", "S", "W"};
        double[][] dirs = {{0, -1}, {1, 0}, {0, 1}, {-1, 0}};
        double c = Math.cos(phi);
        double s = Math.sin(phi);
        for (int i = 0; i < 4; i++) {
            double wx = dirs[i][0];
            double wz = dirs[i][1];
            double sx = wx * c - wz * s;
            double sy = wx * s + wz * c;
            int x = (int) Math.round(cx + sx * r);
            int y = (int) Math.round(cy + sy * r);
            g.fill(x - 5, y - 5, x + 5, y + 5, 0xFF000000);
            g.fill(x - 4, y - 4, x + 4, y + 4, i == 0 ? 0xFFC03030 : 0xFF3A5FCD);
            g.drawString(font, letters[i], x - 2, y - 4, 0xFFFFFF, false);
        }
    }

    // ---------- точки ----------

    private static final String[] SKULL = {
            "..WWWW..",
            ".WWWWWW.",
            "WWWWWWWW",
            "WKKWWKKW",
            "WKKWWKKW",
            "WWWKKWWW",
            ".WWWWWW.",
            ".W.W.W.."
    };

    private static void skull(GuiGraphics g, int x, int y) {
        g.fill(x - 5, y - 5, x + 5, y + 5, 0xFF000000);
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                char ch = SKULL[r].charAt(c);
                if (ch == '.') continue;
                g.fill(x - 4 + c, y - 4 + r, x - 3 + c, y - 3 + r, ch == 'W' ? 0xFFF0F0F0 : 0xFF202020);
            }
        }
    }

    private static void diamond(GuiGraphics g, int x, int y, int color) {
        for (int dy = -5; dy <= 5; dy++) {
            int hw = 5 - Math.abs(dy);
            g.fill(x - hw, y + dy, x + hw + 1, y + dy + 1, 0xFF000000);
        }
        for (int dy = -4; dy <= 4; dy++) {
            int hw = 4 - Math.abs(dy);
            g.fill(x - hw, y + dy, x + hw + 1, y + dy + 1, 0xFF000000 | color);
        }
    }

    public static void waypoint(GuiGraphics g, Waypoint w, int x, int y) {
        if ("Death point".equals(w.name)) {
            skull(g, x, y);
        } else {
            diamond(g, x, y, w.color);
        }
    }

    // ---------- мобы и игроки ----------

    public static void draw(GuiGraphics g, LivingEntity e, int cx, int cy, int size) {
        Minecraft mc = Minecraft.getInstance();
        boolean hostile = e instanceof Enemy;
        boolean isPlayer = e instanceof Player;
        int border = isPlayer ? 0xFFFFFFFF : (hostile ? 0xFFD02020 : 0xFF000000);
        RenderSystem.enableBlend();

        if (e instanceof AbstractClientPlayer p) {
            int x = cx - size / 2;
            int y = cy - size / 2;
            g.fill(x - 1, y - 1, x + size + 1, y + size + 1, border);
            ResourceLocation skin = p.getSkinTextureLocation();
            g.blit(skin, x, y, size, size, 8f, 8f, 8, 8, 64, 64);
            g.blit(skin, x, y, size, size, 40f, 8f, 8, 8, 64, 64);
            return;
        }

        ResourceLocation id = ForgeRegistries.ENTITY_TYPES.getKey(e.getType());
        Face face = (id != null && "minecraft".equals(id.getNamespace())) ? FACES.get(id.getPath()) : null;
        if (face != null) {
            ResourceLocation tex = mc.getEntityRenderDispatcher().getRenderer(e).getTextureLocation(e);
            int w = size;
            int h = Math.max(1, Math.round(size * (float) face.h() / face.w()));
            int x = cx - w / 2;
            int y = cy - h / 2;
            g.fill(x - 1, y - 1, x + w + 1, y + h + 1, border);
            g.blit(tex, x, y, w, h, (float) face.u(), (float) face.v(), face.w(), face.h(), face.tw(), face.th());
            return;
        }

        int col = hostile ? 0xD02020 : 0x40E040;
        g.fill(cx - 3, cy - 3, cx + 3, cy + 3, border);
        g.fill(cx - 2, cy - 2, cx + 2, cy + 2, 0xFF000000 | col);
    }
}
