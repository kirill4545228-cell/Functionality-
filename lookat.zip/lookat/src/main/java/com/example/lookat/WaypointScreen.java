package com.example.lookat;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.List;

/** Список точек: добавить с именем, скрыть/показать, удалить. */
public class WaypointScreen extends Screen {
    private static final int ROW_H = 22;
    private static final int LIST_TOP = 60;

    private final Screen parent;
    private EditBox nameBox;
    private List<Waypoint> list;
    private int page;
    private int perPage = 1;

    public WaypointScreen(Screen parent) {
        super(Component.literal("Waypoints"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        list = WaypointManager.current();
        int cx = width / 2;

        nameBox = new EditBox(font, cx - 140, 28, 180, 20, Component.literal("Name"));
        nameBox.setMaxLength(32);
        nameBox.setHint(Component.literal("Waypoint name"));
        addRenderableWidget(nameBox);

        addRenderableWidget(Button.builder(Component.literal("Add here"), b -> {
            String n = nameBox.getValue().trim();
            WaypointManager.addHere(n.isEmpty() ? null : n);
            nameBox.setValue("");
            rebuildWidgets();
        }).bounds(cx + 44, 28, 66, 20).build());

        perPage = Math.max(1, (height - LIST_TOP - 36) / ROW_H);
        int pages = Math.max(1, (list.size() + perPage - 1) / perPage);
        page = Math.max(0, Math.min(page, pages - 1));
        int start = page * perPage;

        for (int i = 0; i < perPage && start + i < list.size(); i++) {
            Waypoint w = list.get(start + i);
            int y = LIST_TOP + i * ROW_H;
            addRenderableWidget(Button.builder(Component.literal(w.visible ? "Hide" : "Show"), b -> {
                w.visible = !w.visible;
                WaypointManager.save();
                rebuildWidgets();
            }).bounds(cx + 36, y, 44, 20).build());
            addRenderableWidget(Button.builder(Component.literal("X"), b -> {
                WaypointManager.remove(w);
                rebuildWidgets();
            }).bounds(cx + 84, y, 20, 20).build());
        }

        addRenderableWidget(Button.builder(Component.literal("<"), b -> {
            page = Math.max(0, page - 1);
            rebuildWidgets();
        }).bounds(cx - 70, height - 28, 20, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(cx - 30, height - 28, 60, 20).build());
        addRenderableWidget(Button.builder(Component.literal(">"), b -> {
            page = Math.min(pages - 1, page + 1);
            rebuildWidgets();
        }).bounds(cx + 50, height - 28, 20, 20).build());
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        int cx = width / 2;
        g.drawCenteredString(font, "Waypoints  (" + WaypointManager.dimId() + ")", cx, 10, 0xFFFFFF);

        if (list.isEmpty()) {
            g.drawCenteredString(font, "No waypoints here yet", cx, LIST_TOP + 10, 0xAAAAAA);
        }
        int start = page * perPage;
        for (int i = 0; i < perPage && start + i < list.size(); i++) {
            Waypoint w = list.get(start + i);
            int y = LIST_TOP + i * ROW_H;
            g.fill(cx - 140, y + 4, cx - 128, y + 16, 0xFF000000);
            g.fill(cx - 139, y + 5, cx - 129, y + 15, 0xFF000000 | w.color);
            int c = w.visible ? 0xFFFFFF : 0x777777;
            g.drawString(font, font.plainSubstrByWidth(w.name, 70), cx - 124, y + 6, c, true);
            String xyz = w.x + ", " + w.y + ", " + w.z;
            g.drawString(font, font.plainSubstrByWidth(xyz, 78), cx - 50, y + 6, 0xAAAAAA, true);
        }
        int pages = Math.max(1, (list.size() + perPage - 1) / perPage);
        g.drawCenteredString(font, (page + 1) + "/" + pages, cx, height - 42, 0xFFFFFF);
        super.render(g, mx, my, pt);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void onClose() {
        Minecraft.getInstance().setScreen(parent);
    }
}
