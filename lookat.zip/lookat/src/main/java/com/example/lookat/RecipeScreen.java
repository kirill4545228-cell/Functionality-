package com.example.lookat;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.ChatFormatting;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.core.NonNullList;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.AbstractFurnaceMenu;
import net.minecraft.world.inventory.CraftingMenu;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.inventory.RecipeBookMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.AbstractCookingRecipe;
import net.minecraft.world.item.crafting.CraftingRecipe;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.ShapedRecipe;
import net.minecraft.world.item.crafting.ShapelessRecipe;
import net.minecraft.world.item.crafting.SmithingRecipe;
import net.minecraft.world.level.Level;
import net.minecraftforge.common.ForgeHooks;
import net.minecraftforge.registries.ForgeRegistries;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

/** Экран рецептов (R) и использований (U) в стиле ванильного GUI / JEI. */
public class RecipeScreen extends Screen {
    private static final int W = 176, H = 112;

    private enum Kind { CRAFT, COOK, SINGLE, SMITH, GENERIC }

    /** Ячейка с предметом(ами); если вариантов несколько — они листаются. */
    private static final class Cell {
        final int x, y, size;
        final List<ItemStack> alts;
        final boolean bg, fuel;

        Cell(int x, int y, int size, List<ItemStack> alts, boolean bg, boolean fuel) {
            this.x = x;
            this.y = y;
            this.size = size;
            this.alts = alts;
            this.bg = bg;
            this.fuel = fuel;
        }

        int off() {
            return (size - 16) / 2;
        }

        boolean contains(double mx, double my) {
            return mx >= x && mx < x + size && my >= y && my < y + size;
        }

        ItemStack shown(ItemStack focus) {
            if (alts.isEmpty()) return ItemStack.EMPTY;
            for (ItemStack s : alts) {
                if (s.is(focus.getItem())) return s;
            }
            return alts.get((int) ((Util.getMillis() / 1000L) % alts.size()));
        }
    }

    private static final class Layout {
        final Kind kind;
        final List<Cell> cells = new ArrayList<>();
        int arrowX, arrowY;
        int flameX = -1, flameY;
        String info1, info2;

        Layout(Kind kind) {
            this.kind = kind;
        }
    }

    private final Screen parent;
    private final ItemStack focus;
    private final boolean usages;
    private final List<Recipe<?>> recipes;
    private final Map<Recipe<?>, List<List<ItemStack>>> smithCache = new HashMap<>();
    private int index;
    private int left, top;
    private Button fillBtn;

    private static List<ItemStack> fuels;

    private RecipeScreen(Screen parent, ItemStack focus, boolean usages, List<Recipe<?>> recipes) {
        super(Component.literal(usages ? "Usages" : "Recipes"));
        this.parent = parent;
        this.focus = focus;
        this.usages = usages;
        this.recipes = recipes;
    }

    // ================= поиск рецептов =================

    public static void open(Screen parent, ItemStack stack, boolean usages) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || stack.isEmpty()) return;
        List<Recipe<?>> list = usages ? using(stack, mc.level) : producing(stack, mc.level);
        if (list.isEmpty()) {
            if (mc.player != null) {
                mc.player.displayClientMessage(
                        Component.literal(usages ? "No usages found" : "No recipes found"), true);
            }
            return;
        }
        list.sort((a, b) -> {
            int c = sortKey(a).compareTo(sortKey(b));
            return c != 0 ? c : a.getId().compareTo(b.getId());
        });
        mc.setScreen(new RecipeScreen(parent, stack, usages, list));
    }

    private static String sortKey(Recipe<?> r) {
        ResourceLocation k = ForgeRegistries.RECIPE_TYPES.getKey(r.getType());
        if (k == null) return "z";
        return ("minecraft".equals(k.getNamespace()) ? "0" : "1") + k;
    }

    private static List<Recipe<?>> producing(ItemStack target, Level level) {
        List<Recipe<?>> out = new ArrayList<>();
        for (Recipe<?> r : level.getRecipeManager().getRecipes()) {
            ItemStack res = r.getResultItem(level.registryAccess());
            if (!res.isEmpty() && res.is(target.getItem())) out.add(r);
        }
        return out;
    }

    private static List<Recipe<?>> using(ItemStack target, Level level) {
        List<Recipe<?>> out = new ArrayList<>();
        for (Recipe<?> r : level.getRecipeManager().getRecipes()) {
            boolean hit = false;
            if (r instanceof SmithingRecipe sr) {
                hit = sr.isTemplateIngredient(target) || sr.isBaseIngredient(target)
                        || sr.isAdditionIngredient(target);
            } else {
                for (Ingredient ing : r.getIngredients()) {
                    if (!ing.isEmpty() && ing.test(target)) {
                        hit = true;
                        break;
                    }
                }
            }
            if (hit) out.add(r);
        }
        return out;
    }

    // ================= вспомогательное =================

    static double mouseX() {
        Minecraft mc = Minecraft.getInstance();
        return mc.mouseHandler.xpos() * mc.getWindow().getGuiScaledWidth() / mc.getWindow().getScreenWidth();
    }

    static double mouseY() {
        Minecraft mc = Minecraft.getInstance();
        return mc.mouseHandler.ypos() * mc.getWindow().getGuiScaledHeight() / mc.getWindow().getScreenHeight();
    }

    private static List<ItemStack> alts(Ingredient ing) {
        if (ing.isEmpty()) return List.of();
        return Arrays.asList(ing.getItems());
    }

    private static List<ItemStack> fuels() {
        if (fuels == null) {
            List<ItemStack> l = new ArrayList<>();
            for (ItemStack s : ItemIndex.all()) {
                if (ForgeHooks.getBurnTime(s, RecipeType.SMELTING) > 0) l.add(s);
            }
            l.sort((a, b) -> Integer.compare(ForgeHooks.getBurnTime(b, RecipeType.SMELTING),
                    ForgeHooks.getBurnTime(a, RecipeType.SMELTING)));
            fuels = l.size() > 12 ? new ArrayList<>(l.subList(0, 12)) : l;
        }
        return fuels;
    }

    private List<List<ItemStack>> smithing(SmithingRecipe sr) {
        return smithCache.computeIfAbsent(sr, k -> {
            List<ItemStack> t = new ArrayList<>();
            List<ItemStack> b = new ArrayList<>();
            List<ItemStack> a = new ArrayList<>();
            for (ItemStack s : ItemIndex.all()) {
                if (sr.isTemplateIngredient(s)) t.add(s);
                if (sr.isBaseIngredient(s)) b.add(s);
                if (sr.isAdditionIngredient(s)) a.add(s);
            }
            List<List<ItemStack>> res = new ArrayList<>();
            res.add(t);
            res.add(b);
            res.add(a);
            return res;
        });
    }

    private static String typePath(Recipe<?> r) {
        ResourceLocation k = ForgeRegistries.RECIPE_TYPES.getKey(r.getType());
        return k == null ? "" : k.getPath();
    }

    private static String typeTitle(Recipe<?> r) {
        ResourceLocation k = ForgeRegistries.RECIPE_TYPES.getKey(r.getType());
        if (k == null) return "Recipe";
        StringBuilder sb = new StringBuilder();
        for (String part : k.getPath().split("_")) {
            if (part.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        String s = sb.toString();
        if ("campfire cooking".equalsIgnoreCase(s)) s = "Campfire Cooking";
        return "minecraft".equals(k.getNamespace()) ? s : s + " (" + k.getNamespace() + ")";
    }

    private static ItemStack station(Recipe<?> r) {
        ResourceLocation k = ForgeRegistries.RECIPE_TYPES.getKey(r.getType());
        if (k == null || !"minecraft".equals(k.getNamespace())) return ItemStack.EMPTY;
        return switch (k.getPath()) {
            case "crafting" -> new ItemStack(Items.CRAFTING_TABLE);
            case "smelting" -> new ItemStack(Items.FURNACE);
            case "blasting" -> new ItemStack(Items.BLAST_FURNACE);
            case "smoking" -> new ItemStack(Items.SMOKER);
            case "campfire_cooking" -> new ItemStack(Items.CAMPFIRE);
            case "stonecutting" -> new ItemStack(Items.STONECUTTER);
            case "smithing" -> new ItemStack(Items.SMITHING_TABLE);
            default -> ItemStack.EMPTY;
        };
    }

    private AbstractContainerScreen<?> root() {
        Screen s = parent;
        while (s instanceof RecipeScreen rs) s = rs.parent;
        return s instanceof AbstractContainerScreen<?> a ? a : null;
    }

    private boolean canFill(Recipe<?> r) {
        AbstractContainerScreen<?> rs = root();
        if (rs == null) return false;
        AbstractContainerMenu m = rs.getMenu();
        if (!(m instanceof RecipeBookMenu<?>)) return false;
        if (m instanceof CraftingMenu || m instanceof InventoryMenu) return r instanceof CraftingRecipe;
        if (m instanceof AbstractFurnaceMenu) return r instanceof AbstractCookingRecipe;
        return false;
    }

    private void fill() {
        Minecraft mc = Minecraft.getInstance();
        AbstractContainerScreen<?> rs = root();
        if (rs == null || mc.gameMode == null) return;
        mc.gameMode.handlePlaceRecipe(rs.getMenu().containerId, recipes.get(index), Screen.hasShiftDown());
        mc.setScreen(rs);
    }

    private void change(int d) {
        index = Math.floorMod(index + d, recipes.size());
    }

    // ================= раскладка =================

    private Layout buildLayout(Recipe<?> r) {
        Minecraft mc = Minecraft.getInstance();
        ItemStack result = mc.level == null ? ItemStack.EMPTY : r.getResultItem(mc.level.registryAccess());
        List<ItemStack> resAlts = result.isEmpty() ? new ArrayList<>() : List.of(result);
        NonNullList<Ingredient> ings = r.getIngredients();
        Layout L;

        if (r instanceof SmithingRecipe sr) {
            L = new Layout(Kind.SMITH);
            List<List<ItemStack>> parts = smithing(sr);
            int[] xs = {10, 38, 66};
            for (int i = 0; i < 3; i++) {
                L.cells.add(new Cell(left + xs[i], top + 53, 18, parts.get(i), true, false));
            }
            L.arrowX = left + 91;
            L.arrowY = top + 55;
        } else if (r instanceof AbstractCookingRecipe cr) {
            L = new Layout(Kind.COOK);
            List<ItemStack> in = ings.isEmpty() ? new ArrayList<>() : alts(ings.get(0));
            L.cells.add(new Cell(left + 50, top + 34, 18, in, true, false));
            L.cells.add(new Cell(left + 50, top + 72, 18, fuels(), true, true));
            L.flameX = left + 53;
            L.flameY = top + 56;
            L.arrowX = left + 91;
            L.arrowY = top + 55;
            L.info1 = String.format(Locale.ROOT, "%.1fs", cr.getCookingTime() / 20.0);
            L.info2 = String.format(Locale.ROOT, "%.2f xp", cr.getExperience());
        } else if (r instanceof CraftingRecipe) {
            L = new Layout(Kind.CRAFT);
            fillGrid(L, r, ings);
        } else if (ings.size() <= 1) {
            L = new Layout(Kind.SINGLE);
            List<ItemStack> in = ings.isEmpty() ? new ArrayList<>() : alts(ings.get(0));
            L.cells.add(new Cell(left + 50, top + 53, 18, in, true, false));
            L.arrowX = left + 91;
            L.arrowY = top + 55;
        } else {
            L = new Layout(Kind.GENERIC);
            fillGrid(L, r, ings);
        }

        L.cells.add(new Cell(left + 133, top + 49, 26, resAlts, true, false));
        ItemStack st = station(r);
        if (!st.isEmpty()) L.cells.add(new Cell(left + 8, top + 6, 16, List.of(st), false, false));
        return L;
    }

    private void fillGrid(Layout L, Recipe<?> r, NonNullList<Ingredient> ings) {
        List<List<ItemStack>> grid = new ArrayList<>();
        for (int i = 0; i < 9; i++) grid.add(new ArrayList<>());
        boolean shaped = r instanceof ShapedRecipe;
        int w = shaped ? Math.max(1, ((ShapedRecipe) r).getWidth()) : 3;
        for (int i = 0; i < ings.size(); i++) {
            int p = shaped ? (i / w) * 3 + (i % w) : i;
            if (p >= 9) continue;
            grid.set(p, alts(ings.get(i)));
        }
        for (int p = 0; p < 9; p++) {
            L.cells.add(new Cell(left + 17 + (p % 3) * 18, top + 35 + (p / 3) * 18, 18, grid.get(p), true, false));
        }
        L.arrowX = left + 91;
        L.arrowY = top + 55;
    }

    private Cell hovered(Layout L, double mx, double my) {
        for (Cell c : L.cells) {
            if (c.contains(mx, my)) return c;
        }
        return null;
    }

    // ================= рисование =================

    private static void panel(GuiGraphics g, int x, int y, int w, int h) {
        g.fill(x, y, x + w, y + h, 0xFF000000);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, 0xFFC6C6C6);
        g.fill(x + 1, y + 1, x + w - 2, y + 3, 0xFFFFFFFF);
        g.fill(x + 1, y + 1, x + 3, y + h - 2, 0xFFFFFFFF);
        g.fill(x + 2, y + h - 3, x + w - 1, y + h - 1, 0xFF555555);
        g.fill(x + w - 3, y + 2, x + w - 1, y + h - 1, 0xFF555555);
    }

    private static void slotBg(GuiGraphics g, int x, int y, int s) {
        g.fill(x, y, x + s, y + s, 0xFF8B8B8B);
        g.fill(x, y, x + s - 1, y + 1, 0xFF373737);
        g.fill(x, y, x + 1, y + s - 1, 0xFF373737);
        g.fill(x + 1, y + s - 1, x + s, y + s, 0xFFFFFFFF);
        g.fill(x + s - 1, y + 1, x + s, y + s, 0xFFFFFFFF);
    }

    private static void outline(GuiGraphics g, int x, int y, int s, int c) {
        g.fill(x, y, x + s, y + 1, c);
        g.fill(x, y + s - 1, x + s, y + s, c);
        g.fill(x, y, x + 1, y + s, c);
        g.fill(x + s - 1, y, x + s, y + s, c);
    }

    private static void arrowShape(GuiGraphics g, int x, int y, int cols, int color) {
        int cy = y + 7;
        for (int c = 0; c < cols && c < 22; c++) {
            if (c < 14) {
                g.fill(x + c, cy - 2, x + c + 1, cy + 3, color);
            } else {
                int half = 7 - (c - 14);
                g.fill(x + c, cy - half, x + c + 1, cy + half + 1, color);
            }
        }
    }

    private static final int[] FLAME_W = {2, 4, 4, 6, 8, 8, 10, 10, 12, 12, 12, 10};

    private static void flame(GuiGraphics g, int x, int y, float lit) {
        int rows = FLAME_W.length;
        int litRows = Math.round(rows * lit);
        for (int r = 0; r < rows; r++) {
            int ww = FLAME_W[r];
            int x0 = x + 6 - ww / 2;
            boolean on = r >= rows - litRows;
            g.fill(x0, y + r, x0 + ww, y + r + 1, on ? 0xFFFF8C00 : 0xFF8B8B8B);
            if (on && r >= 4) {
                int iw = Math.max(2, ww - 6);
                int ix = x + 6 - iw / 2;
                g.fill(ix, y + r, ix + iw, y + r + 1, 0xFFFFE066);
            }
        }
    }

    private void text(GuiGraphics g, String s, int x, int y, int color) {
        g.drawString(font, s, x, y, color, false);
    }

    // ================= Screen =================

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2 - 6;
        addRenderableWidget(Button.builder(Component.literal("<"), b -> change(-1))
                .bounds(left, top + H + 4, 20, 20).build());
        addRenderableWidget(Button.builder(Component.literal(">"), b -> change(1))
                .bounds(left + W - 20, top + H + 4, 20, 20).build());
        fillBtn = addRenderableWidget(Button.builder(Component.literal("Move items"), b -> fill())
                .bounds(left + W / 2 - 42, top + H + 4, 84, 20).build());
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        Recipe<?> r = recipes.get(index);
        Layout L = buildLayout(r);
        long now = Util.getMillis();

        g.drawCenteredString(font, (usages ? "Usages: " : "Recipes: ") + focus.getHoverName().getString(),
                width / 2, top - 14, 0xFFFFFF);

        panel(g, left, top, W, H);

        // шапка
        text(g, font.plainSubstrByWidth(typeTitle(r), W - 100), left + 30, top + 10, 0x404040);
        String tag = r instanceof ShapedRecipe ? "Shaped" : (r instanceof ShapelessRecipe ? "Shapeless" : "");
        if (!tag.isEmpty()) text(g, tag, left + W - 8 - font.width(tag), top + 10, 0x707070);
        g.fill(left + 6, top + 25, left + W - 6, top + 26, 0xFF8B8B8B);
        g.fill(left + 6, top + 26, left + W - 6, top + 27, 0xFFFFFFFF);

        // подвал
        g.fill(left + 6, top + H - 19, left + W - 6, top + H - 18, 0xFF8B8B8B);
        g.fill(left + 6, top + H - 18, left + W - 6, top + H - 17, 0xFFFFFFFF);
        String pg = (index + 1) + "/" + recipes.size();
        int pgW = font.width(pg);
        text(g, pg, left + W - 8 - pgW, top + H - 13, 0x555555);
        text(g, font.plainSubstrByWidth(r.getId().toString(), W - 24 - pgW), left + 8, top + H - 13, 0x707070);

        // декор по типу
        if (L.kind == Kind.SMITH) {
            text(g, "+", left + 31, top + 57, 0x555555);
            text(g, "+", left + 59, top + 57, 0x555555);
        }
        if (L.flameX >= 0) {
            float lit = 1f - (now % 1500L) / 1500f;
            flame(g, L.flameX, L.flameY, lit);
        }
        float progress = (now % 2000L) / 2000f;
        arrowShape(g, L.arrowX, L.arrowY, 22, 0xFF8B8B8B);
        arrowShape(g, L.arrowX, L.arrowY, (int) (22 * progress), 0xFFFFFFFF);
        if (L.info1 != null) {
            int cx = L.arrowX + 11;
            text(g, L.info1, cx - font.width(L.info1) / 2, top + 76, 0x555555);
            text(g, L.info2, cx - font.width(L.info2) / 2, top + 86, 0x555555);
        }

        // ячейки
        for (Cell c : L.cells) {
            ItemStack s = c.shown(focus);
            if (c.bg) {
                slotBg(g, c.x, c.y, c.size);
                if (!s.isEmpty() && s.is(focus.getItem())) outline(g, c.x, c.y, c.size, 0xFFFFD83A);
            }
            if (!s.isEmpty()) {
                g.renderItem(s, c.x + c.off(), c.y + c.off());
                g.renderItemDecorations(font, s, c.x + c.off(), c.y + c.off());
            }
        }

        fillBtn.visible = canFill(r);
        super.render(g, mx, my, pt);

        Cell h = hovered(L, mx, my);
        if (h != null) {
            ItemStack s = h.shown(focus);
            if (!s.isEmpty()) {
                List<Component> lines = new ArrayList<>(Screen.getTooltipFromItem(Minecraft.getInstance(), s));
                if (h.fuel) {
                    double sec = ForgeHooks.getBurnTime(s, RecipeType.SMELTING) / 20.0;
                    lines.add(Component.literal(String.format(Locale.ROOT, "Burn time: %.1fs", sec))
                            .withStyle(ChatFormatting.GOLD));
                }
                g.renderTooltip(font, lines, Optional.empty(), mx, my);
            }
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        Cell h = hovered(buildLayout(recipes.get(index)), mx, my);
        if (h != null && (btn == 0 || btn == 1)) {
            ItemStack s = h.shown(focus);
            if (!s.isEmpty()) {
                if (!(s.is(focus.getItem()) && (btn == 1) == usages)) open(this, s, btn == 1);
                return true;
            }
        }
        return super.mouseClicked(mx, my, btn);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        change(delta < 0 ? 1 : -1);
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int mods) {
        if (keyCode == GLFW.GLFW_KEY_LEFT) {
            change(-1);
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_RIGHT) {
            change(1);
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
            onClose();
            return true;
        }
        InputConstants.Key key = InputConstants.getKey(keyCode, scanCode);
        boolean rec = Keys.SHOW_RECIPES.isActiveAndMatches(key);
        boolean use = Keys.SHOW_USAGES.isActiveAndMatches(key);
        boolean bm = Keys.BOOKMARK.isActiveAndMatches(key);
        if (rec || use || bm) {
            Cell h = hovered(buildLayout(recipes.get(index)), mouseX(), mouseY());
            if (h != null) {
                ItemStack s = h.shown(focus);
                if (!s.isEmpty()) {
                    if (bm) {
                        boolean on = Bookmarks.toggle(s);
                        if (minecraft != null && minecraft.player != null) {
                            minecraft.player.displayClientMessage(Component.literal(
                                    (on ? "Bookmarked: " : "Removed bookmark: ") + s.getHoverName().getString()), true);
                        }
                    } else {
                        open(this, s, use);
                    }
                    return true;
                }
            }
        }
        return super.keyPressed(keyCode, scanCode, mods);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void onClose() {
        minecraft.setScreen(parent);
    }
}
