package com.example.lookat;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.NonNullList;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.ShapedRecipe;
import net.minecraft.world.level.Level;
import net.minecraftforge.registries.ForgeRegistries;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/** Экран рецептов (R) и использований (U). */
public class RecipeScreen extends Screen {
    private static final int W = 176, H = 104;

    private final Screen parent;
    private final ItemStack focus;
    private final boolean usages;
    private final List<Recipe<?>> recipes;
    private int index;
    private int left, top;

    private record Entry(int x, int y, ItemStack stack) {
    }

    private RecipeScreen(Screen parent, ItemStack focus, boolean usages, List<Recipe<?>> recipes) {
        super(Component.literal(usages ? "Usages" : "Recipes"));
        this.parent = parent;
        this.focus = focus;
        this.usages = usages;
        this.recipes = recipes;
    }

    // ---------- поиск рецептов ----------

    public static void open(Screen parent, ItemStack stack, boolean usages) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || stack.isEmpty()) return;
        List<Recipe<?>> list = usages ? using(stack, mc.level) : producing(stack, mc.level);
        if (list.isEmpty()) {
            if (mc.player != null) {
                mc.player.displayClientMessage(
                        Component.literal(usages ? "No usages found" : "No recipes found"), true);
            }
            return;
        }
        mc.setScreen(new RecipeScreen(parent, stack, usages, list));
    }

    private static List<Recipe<?>> producing(ItemStack target, Level level) {
        List<Recipe<?>> out = new ArrayList<>();
        for (Recipe<?> r : level.getRecipeManager().getRecipes()) {
            ItemStack res = r.getResultItem(level.registryAccess());
            if (!res.isEmpty() && res.is(target.getItem())) out.add(r);
        }
        return out;
    }

    private static List<Recipe<?>> using(ItemStack target, Level level) {
        List<Recipe<?>> out = new ArrayList<>();
        for (Recipe<?> r : level.getRecipeManager().getRecipes()) {
            for (Ingredient ing : r.getIngredients()) {
                if (!ing.isEmpty() && ing.test(target)) {
                    out.add(r);
                    break;
                }
            }
        }
        return out;
    }

    // ---------- вспомогательное ----------

    static double mouseX() {
        Minecraft mc = Minecraft.getInstance();
        return mc.mouseHandler.xpos() * mc.getWindow().getGuiScaledWidth() / mc.getWindow().getScreenWidth();
    }

    static double mouseY() {
        Minecraft mc = Minecraft.getInstance();
        return mc.mouseHandler.ypos() * mc.getWindow().getGuiScaledHeight() / mc.getWindow().getScreenHeight();
    }

    private static ItemStack shown(Ingredient ing) {
        ItemStack[] items = ing.getItems();
        if (items.length == 0) return ItemStack.EMPTY;
        return items[(int) ((Util.getMillis() / 1000L) % items.length)];
    }

    private static String typeName(Recipe<?> r) {
        ResourceLocation k = ForgeRegistries.RECIPE_TYPES.getKey(r.getType());
        if (k == null) return "Recipe";
        String p = k.getPath().replace('_', ' ');
        if (!p.isEmpty()) p = Character.toUpperCase(p.charAt(0)) + p.substring(1);
        return "minecraft".equals(k.getNamespace()) ? p : p + " (" + k.getNamespace() + ")";
    }

    private List<Entry> entries(Recipe<?> r) {
        List<Entry> out = new ArrayList<>();
        Level level = Minecraft.getInstance().level;
        if (level == null) return out;

        NonNullList<Ingredient> ings = r.getIngredients();
        int n = ings.size();
        int cols = 3;
        if (r instanceof ShapedRecipe sr) {
            cols = Math.max(1, sr.getWidth());
        } else if (n <= 3) {
            cols = Math.max(1, n);
        }
        int rows = Math.max(1, (n + cols - 1) / cols);
        int gx = left + 14 + (3 - Math.min(cols, 3)) * 9;
        int gy = top + 28 + (3 - Math.min(rows, 3)) * 9;

        for (int i = 0; i < n; i++) {
            ItemStack s = shown(ings.get(i));
            if (s.isEmpty()) continue;
            out.add(new Entry(gx + (i % cols) * 18, gy + (i / cols) * 18, s));
        }
        ItemStack res = r.getResultItem(level.registryAccess());
        if (!res.isEmpty()) out.add(new Entry(left + 118, top + 46, res));
        return out;
    }

    private static Entry hovered(List<Entry> es, double mx, double my) {
        for (Entry e : es) {
            if (mx >= e.x() && mx < e.x() + 16 && my >= e.y() && my < e.y() + 16) return e;
        }
        return null;
    }

    private void change(int d) {
        index = Math.floorMod(index + d, recipes.size());
    }

    // ---------- Screen ----------

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2;
        addRenderableWidget(Button.builder(Component.literal("<"), b -> change(-1))
                .bounds(left, top + H + 4, 20, 20).build());
        addRenderableWidget(Button.builder(Component.literal(">"), b -> change(1))
                .bounds(left + W - 20, top + H + 4, 20, 20).build());
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        g.drawCenteredString(font, (usages ? "Usages: " : "Recipes: ") + focus.getHoverName().getString(),
                width / 2, top - 14, 0xFFFFFF);

        g.fill(left - 1, top - 1, left + W + 1, top + H + 1, 0xFF000000);
        g.fill(left, top, left + W, top + H, 0xFFC6C6C6);

        Recipe<?> r = recipes.get(index);
        g.drawString(font, font.plainSubstrByWidth(typeName(r), W - 12), left + 6, top + 6, 0x404040, false);
        g.drawString(font, "=>", left + 92, top + 50, 0x404040, false);
        g.drawString(font, font.plainSubstrByWidth(r.getId().toString(), W - 12),
                left + 6, top + H - 12, 0x707070, false);

        List<Entry> es = entries(r);
        for (Entry e : es) {
            g.fill(e.x() - 1, e.y() - 1, e.x() + 17, e.y() + 17, 0xFF8B8B8B);
            g.renderItem(e.stack(), e.x(), e.y());
            g.renderItemDecorations(font, e.stack(), e.x(), e.y());
        }

        g.drawCenteredString(font, (index + 1) + " / " + recipes.size(), width / 2, top + H + 10, 0xFFFFFF);
        super.render(g, mx, my, pt);

        Entry h = hovered(es, mx, my);
        if (h != null) g.renderTooltip(font, h.stack(), mx, my);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        Entry h = hovered(entries(recipes.get(index)), mx, my);
        if (h != null && (btn == 0 || btn == 1)) {
            open(this, h.stack(), btn == 1);
            return true;
        }
        return super.mouseClicked(mx, my, btn);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        change(delta < 0 ? 1 : -1);
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int mods) {
        if (keyCode == GLFW.GLFW_KEY_LEFT) {
            change(-1);
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_RIGHT) {
            change(1);
            return true;
        }
        InputConstants.Key key = InputConstants.getKey(keyCode, scanCode);
        boolean rec = Keys.SHOW_RECIPES.isActiveAndMatches(key);
        boolean use = Keys.SHOW_USAGES.isActiveAndMatches(key);
        if (rec || use) {
            Entry h = hovered(entries(recipes.get(index)), mouseX(), mouseY());
            if (h != null) {
                open(this, h.stack(), use);
                return true;
            }
        }
        return super.keyPressed(keyCode, scanCode, mods);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void onClose() {
        minecraft.setScreen(parent);
    }
}
