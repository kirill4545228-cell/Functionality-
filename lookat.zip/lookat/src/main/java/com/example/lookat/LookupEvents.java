package com.example.lookat;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** R / U прямо в игре: рецепты/использования блока под прицелом или предмета в руке. */
@Mod.EventBusSubscriber(modid = LookAtMod.MODID, value = Dist.CLIENT)
public final class LookupEvents {
    private LookupEvents() {
    }

    private static ItemStack target(Minecraft mc) {
        if (mc.hitResult instanceof BlockHitResult bhr && bhr.getType() == HitResult.Type.BLOCK
                && mc.level != null && mc.player != null) {
            BlockPos pos = bhr.getBlockPos();
            BlockState st = mc.level.getBlockState(pos);
            ItemStack s = st.getCloneItemStack(bhr, mc.level, pos, mc.player);
            if (!s.isEmpty()) return s;
        }
        return mc.player == null ? ItemStack.EMPTY : mc.player.getMainHandItem();
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        while (Keys.LOOKUP_RECIPES.consumeClick()) {
            go(mc, false);
        }
        while (Keys.LOOKUP_USAGES.consumeClick()) {
            go(mc, true);
        }
    }

    private static void go(Minecraft mc, boolean usages) {
        ItemStack s = target(mc);
        if (s.isEmpty()) {
            mc.player.displayClientMessage(Component.literal("Look at a block or hold an item"), true);
            return;
        }
        RecipeScreen.open(null, s, usages);
    }
}
