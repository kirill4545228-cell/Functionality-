package com.example.lookat;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = LookAtMod.MODID, value = Dist.CLIENT,
        bus = Mod.EventBusSubscriber.Bus.MOD)
public final class Keys {
    public static final KeyMapping SHOW_RECIPES = new KeyMapping("key.lookat.recipes",
            KeyConflictContext.GUI, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_R, "key.categories.lookat");
    public static final KeyMapping SHOW_USAGES = new KeyMapping("key.lookat.usages",
            KeyConflictContext.GUI, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_U, "key.categories.lookat");

    private Keys() {
    }

    @SubscribeEvent
    public static void register(RegisterKeyMappingsEvent e) {
        e.register(SHOW_RECIPES);
        e.register(SHOW_USAGES);
    }
}
