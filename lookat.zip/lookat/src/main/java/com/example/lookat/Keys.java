package com.example.lookat;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = LookAtMod.MODID, value = Dist.CLIENT,
        bus = Mod.EventBusSubscriber.Bus.MOD)
public final class Keys {
    private static final String CAT = "key.categories.lookat";

    // GUI
    public static final KeyMapping SHOW_RECIPES = new KeyMapping("key.lookat.recipes",
            KeyConflictContext.GUI, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_R, CAT);
    public static final KeyMapping SHOW_USAGES = new KeyMapping("key.lookat.usages",
            KeyConflictContext.GUI, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_U, CAT);

    // In game
    public static final KeyMapping MINIMAP_TOGGLE = new KeyMapping("key.lookat.minimap_toggle",
            KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_M, CAT);
    public static final KeyMapping MINIMAP_ZOOM = new KeyMapping("key.lookat.minimap_zoom",
            KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_Z, CAT);
    public static final KeyMapping RADAR_TOGGLE = new KeyMapping("key.lookat.radar_toggle",
            KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_N, CAT);
    public static final KeyMapping WAYPOINT_ADD = new KeyMapping("key.lookat.waypoint_add",
            KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_B, CAT);
    public static final KeyMapping WAYPOINT_LIST = new KeyMapping("key.lookat.waypoint_list",
            KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_V, CAT);

    private Keys() {
    }

    @SubscribeEvent
    public static void register(RegisterKeyMappingsEvent e) {
        e.register(SHOW_RECIPES);
        e.register(SHOW_USAGES);
        e.register(MINIMAP_TOGGLE);
        e.register(MINIMAP_ZOOM);
        e.register(RADAR_TOGGLE);
        e.register(WAYPOINT_ADD);
        e.register(WAYPOINT_LIST);
    }
}
