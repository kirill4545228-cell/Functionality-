package com.example.lookat;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = LookAtMod.MODID, value = Dist.CLIENT,
        bus = Mod.EventBusSubscriber.Bus.MOD)
public final class Keys {
    private static final String CAT = "key.categories.lookat";

    private static KeyMapping gui(String n, int key) {
        return new KeyMapping(n, KeyConflictContext.GUI, InputConstants.Type.KEYSYM, key, CAT);
    }

    private static KeyMapping game(String n, int key) {
        return new KeyMapping(n, KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, key, CAT);
    }

    // GUI
    public static final KeyMapping SHOW_RECIPES = gui("key.lookat.recipes", GLFW.GLFW_KEY_R);
    public static final KeyMapping SHOW_USAGES = gui("key.lookat.usages", GLFW.GLFW_KEY_U);
    public static final KeyMapping BOOKMARK = gui("key.lookat.bookmark", GLFW.GLFW_KEY_A);

    // In game
    public static final KeyMapping LOOKUP_RECIPES = game("key.lookat.lookup_recipes", GLFW.GLFW_KEY_R);
    public static final KeyMapping LOOKUP_USAGES = game("key.lookat.lookup_usages", GLFW.GLFW_KEY_U);
    public static final KeyMapping FULL_MAP = game("key.lookat.full_map", GLFW.GLFW_KEY_M);
    public static final KeyMapping MINIMAP_TOGGLE = game("key.lookat.minimap_toggle", GLFW.GLFW_KEY_K);
    public static final KeyMapping MINIMAP_ZOOM = game("key.lookat.minimap_zoom", GLFW.GLFW_KEY_Z);
    public static final KeyMapping MINIMAP_ROTATE = game("key.lookat.minimap_rotate", GLFW.GLFW_KEY_G);
    public static final KeyMapping RADAR_TOGGLE = game("key.lookat.radar_toggle", GLFW.GLFW_KEY_N);
    public static final KeyMapping WAYPOINT_ADD = game("key.lookat.waypoint_add", GLFW.GLFW_KEY_B);
    public static final KeyMapping WAYPOINT_LIST = game("key.lookat.waypoint_list", GLFW.GLFW_KEY_V);

    private Keys() {
    }

    @SubscribeEvent
    public static void register(RegisterKeyMappingsEvent e) {
        e.register(SHOW_RECIPES);
        e.register(SHOW_USAGES);
        e.register(BOOKMARK);
        e.register(LOOKUP_RECIPES);
        e.register(LOOKUP_USAGES);
        e.register(FULL_MAP);
        e.register(MINIMAP_TOGGLE);
        e.register(MINIMAP_ZOOM);
        e.register(MINIMAP_ROTATE);
        e.register(RADAR_TOGGLE);
        e.register(WAYPOINT_ADD);
        e.register(WAYPOINT_LIST);
    }
}
