package com.example.lookat;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/** Панель со списком предметов справа от контейнерных экранов (как в JEI). */
@Mod.EventBusSubscriber(modid = LookAtMod.MODID, value = Dist.CLIENT)
public final class ItemListOverlay {
    private static EditBox box;
    private static String query = "";
    private static List<ItemStack> filtered = new ArrayList<>();
    private static int page;
    private static int px, py, cols, rows;

    private ItemListOverlay() {
    }

    private static AbstractContainerScreen<?> eligible(Screen s) {
        if (s instanceof AbstractContainerScreen<?> c && !(s instanceof CreativeModeInventoryScreen)) {
            return c;
        }
        return null;
    }

    private static boolean layout(AbstractContainerScreen<?> c) {
        int left = c.getGuiLeft() + c.getXSize() + 6;
        int w = c.width - left - 4;
        cols = Math.min(w / 18, 12);
        px = left;
        py = 24;
        rows = (c.height - py - 24) / 18;
        return cols >= 2 && rows >= 1;
    }

    private static int perPage() {
        return cols * rows;
    }

    private static int pages() {
        return Math.max(1, (filtered.size() + perPage() - 1) / perPage());
    }

    private static int navY() {
        return py + rows * 18 + 4;
    }

    private static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private static int indexAt(double mx, double my) {
        if (!inside(mx, my, px, py, cols * 18, rows * 18)) return -1;
        int cx = (int) ((mx - px) / 18);
        int cy = (int) ((my - py) / 18);
        int idx = page * perPage() + cy * cols + cx;
        return idx < filtered.size() ? idx : -1;
    }

    private static void refilter() {
        filtered = ItemIndex.search(query);
        page = Math.min(page, pages() - 1);
    }

    private static ItemStack hoveredStack(AbstractContainerScreen<?> c, double mx, double my) {
        int i = indexAt(mx, my);
        if (i >= 0) return filtered.get(i);
        Slot s = c.getSlotUnderMouse();
        if (s != null && s.hasItem()) return s.getItem();
        return ItemStack.EMPTY;
    }

    // ---------- события ----------

    @SubscribeEvent
    public static void onInit(ScreenEvent.Init.Post e) {
        AbstractContainerScreen<?> c = eligible(e.getScreen());
        if (c == null || !layout(c)) {
            box = null;
            return;
        }
        box = new EditBox(Minecraft.getInstance().font, px, 4, cols * 18, 16, Component.literal("Search"));
        box.setMaxLength(64);
        box.setValue(query);
        box.setResponder(t -> {
            query = t;
            page = 0;
            refilter();
        });
        refilter();
    }

    @SubscribeEvent
    public static void onRender(ScreenEvent.Render.Post e) {
        AbstractContainerScreen<?> c = eligible(e.getScreen());
        if (c == null || box == null || !layout(c)) return;
        Minecraft mc = Minecraft.getInstance();
        GuiGraphics g = e.getGuiGraphics();
        int mx = e.getMouseX(), my = e.getMouseY();

        box.render(g, mx, my, e.getPartialTick());

        int per = perPage();
        int start = page * per;
        ItemStack tip = ItemStack.EMPTY;
        for (int i = 0; i < per && start + i < filtered.size(); i++) {
            int x = px + (i % cols) * 18;
            int y = py + (i / cols) * 18;
            ItemStack s = filtered.get(start + i);
            g.fill(x, y, x + 17, y + 17, 0x55000000);
            g.renderItem(s, x + 1, y + 1);
            if (inside(mx, my, x, y, 18, 18)) {
                g.fill(x, y, x + 17, y + 17, 0x80FFFFFF);
                tip = s;
            }
        }

        int ny = navY();
        g.fill(px, ny, px + 18, ny + 14, 0xAA000000);
        g.drawCenteredString(mc.font, "<", px + 9, ny + 3, 0xFFFFFF);
        int rx = px + cols * 18 - 18;
        g.fill(rx, ny, rx + 18, ny + 14, 0xAA000000);
        g.drawCenteredString(mc.font, ">", rx + 9, ny + 3, 0xFFFFFF);
        g.drawCenteredString(mc.font, (page + 1) + "/" + pages(), px + cols * 9, ny + 3, 0xFFFFFF);

        if (!tip.isEmpty()) g.renderTooltip(mc.font, tip, mx, my);
    }

    @SubscribeEvent
    public static void onClick(ScreenEvent.MouseButtonPressed.Pre e) {
        AbstractContainerScreen<?> c = eligible(e.getScreen());
        if (c == null || box == null || !layout(c)) return;
        double mx = e.getMouseX(), my = e.getMouseY();
        int b = e.getButton();

        if (inside(mx, my, px, 4, cols * 18, 16)) {
            box.mouseClicked(mx, my, b);
            if (b == 1) box.setValue("");
            e.setCanceled(true);
            return;
        }
        box.setFocused(false);

        int ny = navY();
        if (inside(mx, my, px, ny, 18, 14)) {
            page = Math.max(0, page - 1);
            e.setCanceled(true);
            return;
        }
        if (inside(mx, my, px + cols * 18 - 18, ny, 18, 14)) {
            page = Math.min(pages() - 1, page + 1);
            e.setCanceled(true);
            return;
        }

        int idx = indexAt(mx, my);
        if (idx >= 0 && (b == 0 || b == 1)) {
            RecipeScreen.open(c, filtered.get(idx), b == 1);
            e.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onScroll(ScreenEvent.MouseScrolled.Pre e) {
        AbstractContainerScreen<?> c = eligible(e.getScreen());
        if (c == null || box == null || !layout(c)) return;
        if (!inside(e.getMouseX(), e.getMouseY(), px, 4, cols * 18, navY() + 14 - 4)) return;
        page = Math.max(0, Math.min(pages() - 1, page + (e.getScrollDelta() < 0 ? 1 : -1)));
        e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onKey(ScreenEvent.KeyPressed.Pre e) {
        AbstractContainerScreen<?> c = eligible(e.getScreen());
        if (c == null || box == null || !layout(c)) return;

        if (box.isFocused()) {
            if (e.getKeyCode() == GLFW.GLFW_KEY_ESCAPE) {
                box.setFocused(false);
            } else {
                box.keyPressed(e.getKeyCode(), e.getScanCode(), e.getModifiers());
            }
            e.setCanceled(true);
            return;
        }

        InputConstants.Key key = InputConstants.getKey(e.getKeyCode(), e.getScanCode());
        boolean rec = Keys.SHOW_RECIPES.isActiveAndMatches(key);
        boolean use = Keys.SHOW_USAGES.isActiveAndMatches(key);
        if (rec || use) {
            ItemStack s = hoveredStack(c, RecipeScreen.mouseX(), RecipeScreen.mouseY());
            if (!s.isEmpty()) {
                RecipeScreen.open(c, s, use);
                e.setCanceled(true);
            }
        }
    }

    @SubscribeEvent
    public static void onChar(ScreenEvent.CharacterTyped.Pre e) {
        AbstractContainerScreen<?> c = eligible(e.getScreen());
        if (c == null || box == null || !box.isFocused()) return;
        box.charTyped(e.getCodePoint(), e.getModifiers());
        e.setCanceled(true);
    }
}
