package com.example.lookat;

import com.google.gson.Gson;
import com.mojang.logging.LogUtils;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.fml.loading.FMLPaths;
import net.minecraftforge.registries.ForgeRegistries;
import org.slf4j.Logger;

import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** Закладки предметов, config/lookat_bookmarks.json. */
public final class Bookmarks {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final Gson GSON = new Gson();
    private static final List<String> IDS = new ArrayList<>();
    private static List<ItemStack> cache;
    private static boolean loaded;

    private Bookmarks() {
    }

    private static Path file() {
        return FMLPaths.CONFIGDIR.get().resolve("lookat_bookmarks.json");
    }

    private static void ensureLoaded() {
        if (loaded) return;
        loaded = true;
        Path f = file();
        if (!Files.exists(f)) return;
        try (Reader r = Files.newBufferedReader(f)) {
            String[] arr = GSON.fromJson(r, String[].class);
            if (arr != null) {
                for (String s : arr) {
                    if (s != null) IDS.add(s);
                }
            }
        } catch (Exception e) {
            LOGGER.error("Failed to load bookmarks", e);
        }
    }

    private static void save() {
        try {
            Files.writeString(file(), GSON.toJson(IDS));
        } catch (IOException e) {
            LOGGER.error("Failed to save bookmarks", e);
        }
    }

    public static List<ItemStack> list() {
        ensureLoaded();
        if (cache == null) {
            List<ItemStack> out = new ArrayList<>();
            for (String id : IDS) {
                ResourceLocation rl = ResourceLocation.tryParse(id);
                if (rl == null) continue;
                Item it = ForgeRegistries.ITEMS.getValue(rl);
                if (it != null && it != Items.AIR) out.add(new ItemStack(it));
            }
            cache = out;
        }
        return cache;
    }

    public static boolean contains(ItemStack s) {
        ensureLoaded();
        ResourceLocation k = ForgeRegistries.ITEMS.getKey(s.getItem());
        return k != null && IDS.contains(k.toString());
    }

    /** @return true, если после вызова предмет в закладках */
    public static boolean toggle(ItemStack s) {
        ensureLoaded();
        ResourceLocation k = ForgeRegistries.ITEMS.getKey(s.getItem());
        if (k == null) return false;
        String id = k.toString();
        boolean now;
        if (IDS.contains(id)) {
            IDS.remove(id);
            now = false;
        } else {
            IDS.add(id);
            now = true;
        }
        cache = null;
        save();
        return now;
    }
}
