package com.example.lookat;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.DeathScreen;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = LookAtMod.MODID, value = Dist.CLIENT)
public final class MinimapEvents {
    private static int counter;
    private static int saveCounter;
    private static boolean deathRecorded;
    private static ClientLevel lastLevel;

    private MinimapEvents() {
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) {
            deathRecorded = false;
            if (lastLevel != null) {
                lastLevel = null;
                Minimap.valid = false;
                MapStore.unload();
            }
            return;
        }

        if (mc.level != lastLevel) {
            lastLevel = mc.level;
            Minimap.valid = false;
            MapStore.setContext(WaypointManager.worldId(), WaypointManager.dimId());
        }

        // точка смерти
        if (mc.screen instanceof DeathScreen) {
            if (!deathRecorded) {
                deathRecorded = true;
                WaypointManager.setDeathPoint();
            }
        } else {
            deathRecorded = false;
        }

        // клавиши
        while (Keys.MINIMAP_TOGGLE.consumeClick()) {
            Minimap.enabled = !Minimap.enabled;
            msg(mc, "Minimap: " + (Minimap.enabled ? "ON" : "OFF"));
        }
        while (Keys.MINIMAP_ZOOM.consumeClick()) {
            Minimap.zoomIdx = (Minimap.zoomIdx + 1) % Minimap.ZOOMS.length;
            msg(mc, "Minimap zoom: " + Minimap.ZOOMS[Minimap.zoomIdx] + " blocks");
        }
        while (Keys.MINIMAP_ROTATE.consumeClick()) {
            Minimap.rotate = !Minimap.rotate;
            msg(mc, "Minimap rotation: " + (Minimap.rotate ? "follows player" : "north up"));
        }
        while (Keys.RADAR_TOGGLE.consumeClick()) {
            Minimap.radarMode = (Minimap.radarMode + 1) % 3;
            String[] names = {"OFF", "hostile + players", "all mobs"};
            msg(mc, "Mob radar: " + names[Minimap.radarMode]);
        }
        while (Keys.WAYPOINT_ADD.consumeClick()) {
            Waypoint w = WaypointManager.addHere(null);
            if (w != null) msg(mc, "Waypoint added: " + w.name);
        }
        while (Keys.WAYPOINT_LIST.consumeClick()) {
            mc.setScreen(new WaypointScreen(null));
        }
        while (Keys.FULL_MAP.consumeClick()) {
            mc.setScreen(new FullMapScreen(null));
        }

        // обновление карты
        if (Minimap.enabled && (!Minimap.valid || ++counter % 10 == 0)) {
            Minimap.update(mc);
        }
        if (++saveCounter % 1200 == 0) {
            MapStore.saveAll();
        }
    }

    private static void msg(Minecraft mc, String s) {
        if (mc.player != null) mc.player.displayClientMessage(Component.literal(s), true);
    }
}
