package com.example.lookat;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.DeathScreen;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = LookAtMod.MODID, value = Dist.CLIENT)
public final class MinimapEvents {
    private static int counter;
    private static boolean deathRecorded;
    private static ClientLevel lastLevel;

    private MinimapEvents() {
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) {
            deathRecorded = false;
            return;
        }

        if (mc.level != lastLevel) {
            lastLevel = mc.level;
            Minimap.valid = false;
        }

        // точка смерти
        if (mc.screen instanceof DeathScreen) {
            if (!deathRecorded) {
                deathRecorded = true;
                WaypointManager.setDeathPoint();
            }
        } else {
            deathRecorded = false;
        }

        // клавиши
        while (Keys.MINIMAP_TOGGLE.consumeClick()) {
            Minimap.enabled = !Minimap.enabled;
            msg(mc, "Minimap: " + (Minimap.enabled ? "ON" : "OFF"));
        }
        while (Keys.MINIMAP_ZOOM.consumeClick()) {
            Minimap.zoomIdx = (Minimap.zoomIdx + 1) % Minimap.ZOOMS.length;
            msg(mc, "Minimap zoom: " + Minimap.ZOOMS[Minimap.zoomIdx] + " blocks");
        }
        while (Keys.RADAR_TOGGLE.consumeClick()) {
            Minimap.radar = !Minimap.radar;
            msg(mc, "Mob radar: " + (Minimap.radar ? "ON" : "OFF"));
        }
        while (Keys.WAYPOINT_ADD.consumeClick()) {
            Waypoint w = WaypointManager.addHere(null);
            if (w != null) msg(mc, "Waypoint added: " + w.name);
        }
        while (Keys.WAYPOINT_LIST.consumeClick()) {
            mc.setScreen(new WaypointScreen(null));
        }

        // обновление карты
        if (Minimap.enabled && (!Minimap.valid || ++counter % 10 == 0)) {
            Minimap.update(mc);
        }
    }

    private static void msg(Minecraft mc, String s) {
        if (mc.player != null) mc.player.displayClientMessage(Component.literal(s), true);
    }
}
